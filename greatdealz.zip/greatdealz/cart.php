<?php
  require_once 'includes/config.php';
  require_once 'includes/functions.php';

  // Handle AJAX requests
  if (isset($_GET['action'])) {
      header('Content-Type: application/json');

      if ($_GET['action'] == 'add') {
          $product_id = (int)$_POST['product_id'];
          $quantity = (int)$_POST['quantity'];
          $result = addToCart($product_id, $quantity);
          echo json_encode(['success' => $result]);
          exit;
      }

      if ($_GET['action'] == 'update') {
          $product_id = (int)$_POST['product_id'];
          $quantity = (int)$_POST['quantity'];
          $result = updateCartQuantity($product_id, $quantity);
          echo json_encode(['success' => $result]);
          exit;
      }

      if ($_GET['action'] == 'remove') {
          $product_id = (int)$_GET['id'];
          $result = removeFromCart($product_id);
          echo json_encode(['success' => $result]);
          exit;
      }
  }

  $cart_items = getCartItems();
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Cart - Greatdealz</title>
      <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/style.css">
      <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/fonts/fontawesome/css/all.min.css">
  </head>
  <body>
      <?php include 'includes/header.php'; ?>
      
      <section class="cart-page container">
          <h2>Your Cart</h2>
          <?php if (empty($cart_items)): ?>
              <p>Your cart is empty.</p>
          <?php else: ?>
              <div class="cart-items">
                  <?php foreach ($cart_items as $item): ?>
                      <div class="cart-item">
                          <img src="<?php echo $item['image_path'] ?: 'assets/images/placeholder.jpg'; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                          <div class="item-details">
                              <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                              <p>Price: <?php echo CURRENCY . ' ' . number_format($item['price'], 2); ?></p>
                              <form onsubmit="updateCart(<?php echo $item['id']; ?>, this.querySelector('input').value); return false;">
                                  <label for="quantity_<?php echo $item['id']; ?>">Quantity: </label>
                                  <input type="number" id="quantity_<?php echo $item['id']; ?>" value="<?php echo $item['quantity']; ?>" min="1">
                                  <button type="submit" class="action-button">Update</button>
                              </form>
                              <a href="cart.php?action=remove&id=<?php echo $item['id']; ?>" class="action-button remove-item" onclick="removeCartItem(<?php echo $item['id']; ?>); return false;">Remove</a>
                          </div>
                          <p class="subtotal"><?php echo CURRENCY . ' ' . number_format($item['price'] * $item['quantity'], 2); ?></p>
                      </div>
                  <?php endforeach; ?>
              </div>
              <div class="cart-summary">
                  <form class="coupon-form">
                      <div class="form-group">
                          <label for="coupon_code">Enter Coupon Code</label>
                          <input type="text" id="coupon_code" placeholder="Enter coupon code">
                      </div>
                      <button type="submit" class="action-button">Apply Coupon</button>
                  </form>
                  <p>Total: <?php
                      $total = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart_items));
                      echo CURRENCY . ' ' . number_format($total, 2);
                  ?></p>
                  <a href="checkout.php" class="action-button proceed-checkout">Proceed to Checkout</a>
                  <a href="products.php" class="action-button continue-shopping">Continue Shopping</a>
              </div>
          <?php endif; ?>
      </section>
      
      <?php include 'includes/footer.php'; ?>
      <script src="<?php echo SITE_URL; ?>assets/js/main.js"></script>
      <script>
          function updateCart(productId, quantity) {
              fetch('cart.php?action=update', {
                  method: 'POST',
                  headers: {
                      'Content-Type': 'application/x-www-form-urlencoded',
                  },
                  body: `product_id=${productId}&quantity=${quantity}`
              })
              .then(response => response.json())
              .then(data => {
                  if (data.success) {
                      location.reload();
                  } else {
                      alert('Error updating quantity.');
                  }
              })
              .catch(error => console.error('Error:', error));
          }

          function removeCartItem(productId) {
              fetch(`cart.php?action=remove&id=${productId}`, {
                  method: 'GET'
              })
              .then(response => response.json())
              .then(data => {
                  if (data.success) {
                      location.reload();
                  } else {
                      alert('Error removing item.');
                  }
              })
              .catch(error => console.error('Error:', error));
          }
      </script>
  </body>
  </html>