<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $address_type = $_POST['address_type'];
    $address_line1 = mysqli_real_escape_string($conn, $_POST['address_line1']);
    $address_line2 = mysqli_real_escape_string($conn, $_POST['address_line2']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $postal_code = mysqli_real_escape_string($conn, $_POST['postal_code']);
    $country = mysqli_real_escape_string($conn, $_POST['country']);
    
    $stmt = $conn->prepare("INSERT INTO addresses (user_id, address_type, address_line1, address_line2, city, postal_code, country) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssss", $_SESSION['user_id'], $address_type, $address_line1, $address_line2, $city, $postal_code, $country);
    if ($stmt->execute()) {
        header('Location: account.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Address - Greatdealz</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="add-address container">
        <h2>Add New Address</h2>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
            <select name="address_type" required>
                <option value="shipping">Shipping</option>
                <option value="billing">Billing</option>
            </select>
            <input type="text" name="address_line1" placeholder="Address Line 1" required>
            <input type="text" name="address_line2" placeholder="Address Line 2">
            <input type="text" name="city" placeholder="City" required>
            <input type="text" name="postal_code" placeholder="Postal Code" required>
            <input type="text" name="country" placeholder="Country" required>
            <button type="submit" class="action-button">Add Address</button>
        </form>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>