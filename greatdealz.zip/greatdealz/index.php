<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

$featured_products = getProducts(null, null, null, null, 'p.created_at DESC', 4); // Get 4 featured products
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Greatdealz - Home</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
    <style>
        .hero {
            background: linear-gradient(135deg, #FF6F61, #FFD700);
            color: #fff;
            text-align: center;
            padding: 100px 20px;
            margin-top: 0;
            position: relative;
            overflow: hidden;
            perspective: 1000px;
            transition: transform 0.3s ease-out;
        }
        .hero-content {
            position: relative;
            z-index: 2;
            transform-style: preserve-3d;
        }
        .hero-3d-scene {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none; /* Prevent interference with mouse events */
        }
        .hero-cube {
            position: absolute;
            width: 50px;
            height: 50px;
            transform-style: preserve-3d;
            animation: float 10s infinite ease-in-out;
        }
        .hero-cube div {
            position: absolute;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(255, 111, 97, 0.4), rgba(255, 215, 0, 0.4));
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .hero-cube .front  { transform: translateZ(25px); }
        .hero-cube .back   { transform: translateZ(-25px) rotateY(180deg); }
        .hero-cube .right  { transform: rotateY(90deg) translateZ(25px); }
        .hero-cube .left   { transform: rotateY(-90deg) translateZ(25px); }
        .hero-cube .top    { transform: rotateX(90deg) translateZ(25px); }
        .hero-cube .bottom { transform: rotateX(-90deg) translateZ(25px); }
        @keyframes float {
            0% {
                transform: translateZ(-100px) rotateX(0deg) rotateY(0deg);
            }
            50% {
                transform: translateZ(100px) rotateX(180deg) rotateY(180deg);
            }
            100% {
                transform: translateZ(-100px) rotateX(360deg) rotateY(360deg);
            }
        }
        /* Position cubes at different locations */
        .hero-cube:nth-child(1) {
            top: 20%;
            left: 15%;
            animation-delay: 0s;
            animation-duration: 12s;
        }
        .hero-cube:nth-child(2) {
            top: 70%;
            left: 25%;
            animation-delay: -2s;
            animation-duration: 15s;
        }
        .hero-cube:nth-child(3) {
            top: 30%;
            right: 20%;
            animation-delay: -4s;
            animation-duration: 10s;
        }
        .hero-cube:nth-child(4) {
            top: 60%;
            right: 10%;
            animation-delay: -6s;
            animation-duration: 13s;
        }
        .hero h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            position: relative;
            z-index: 3;
        }
        .hero p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            position: relative;
            z-index: 3;
        }
        .hero .cta-button {
            background: #6B7280;
            color: #fff;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 5px;
            transition: transform 0.3s, box-shadow 0.3s;
            display: inline-block;
            position: relative;
            z-index: 3;
        }
        .hero .cta-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2rem;
            }
            .hero p {
                font-size: 1rem;
            }
            .hero-cube {
                width: 40px;
                height: 40px;
            }
            .hero-cube div {
                width: 100%;
                height: 100%;
            }
            .hero-cube .front, .hero-cube .back, .hero-cube .right, .hero-cube .left, .hero-cube .top, .hero-cube .bottom {
                transform-origin: center center;
            }
            .hero-cube .front  { transform: translateZ(20px); }
            .hero-cube .back   { transform: translateZ(-20px) rotateY(180deg); }
            .hero-cube .right  { transform: rotateY(90deg) translateZ(20px); }
            .hero-cube .left   { transform: rotateY(-90deg) translateZ(20px); }
            .hero-cube .top    { transform: rotateX(90deg) translateZ(20px); }
            .hero-cube .bottom { transform: rotateX(-90deg) translateZ(20px); }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-3d-scene">
            <div class="hero-cube">
                <div class="front"></div>
                <div class="back"></div>
                <div class="right"></div>
                <div class="left"></div>
                <div class="top"></div>
                <div class="bottom"></div>
            </div>
            <div class="hero-cube">
                <div class="front"></div>
                <div class="back"></div>
                <div class="right"></div>
                <div class="left"></div>
                <div class="top"></div>
                <div class="bottom"></div>
            </div>
            <div class="hero-cube">
                <div class="front"></div>
                <div class="back"></div>
                <div class="right"></div>
                <div class="left"></div>
                <div class="top"></div>
                <div class="bottom"></div>
            </div>
            <div class="hero-cube">
                <div class="front"></div>
                <div class="back"></div>
                <div class="right"></div>
                <div class="left"></div>
                <div class="top"></div>
                <div class="bottom"></div>
            </div>
        </div>
        <div class="hero-content">
            <h1>Welcome to Greatdealz</h1>
            <p>Discover amazing deals on your favorite products!</p>
            <a href="products.php" class="cta-button">Shop Now</a>
        </div>
    </section>
    
    <!-- Featured Products -->
    <section class="featured-products container">
        <h2>Featured Products</h2>
        <div class="product-grid">
            <?php if (empty($featured_products)): ?>
                <p>No featured products available.</p>
            <?php else: ?>
                <?php foreach ($featured_products as $product): ?>
                    <div class="product-card">
                        <img src="<?php echo $product['image_path'] ?: 'assets/images/placeholder.jpg'; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                        <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p><?php echo CURRENCY . ' ' . number_format($product['price'], 2); ?></p>
                        <a href="product-details.php?id=<?php echo $product['id']; ?>" class="view-details">View Details</a>
                        <button onclick="addToCart(<?php echo $product['id']; ?>, 1)" class="add-to-cart">Add to Cart</button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Newsletter -->
    <section class="newsletter">
        <h2>Subscribe to Our Newsletter</h2>
        <form action="subscribe.php" method="post">
            <input type="email" name="email" placeholder="Enter your email" required>
            <button type="submit">Subscribe</button>
        </form>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const hero = document.querySelector('.hero');
            if (hero) {
                hero.addEventListener('mousemove', (e) => {
                    const x = (e.clientX / window.innerWidth - 0.5) * 10; // Subtle tilt
                    const y = (e.clientY / window.innerHeight - 0.5) * 10;
                    hero.style.transform = `perspective(1000px) rotateX(${y}deg) rotateY(${x}deg)`;
                });
                
                hero.addEventListener('mouseleave', () => {
                    hero.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
                });
            }
        });

        function addToCart(productId, quantity) {
            fetch('cart.php?action=add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `product_id=${productId}&quantity=${quantity}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Product added to cart!');
                } else {
                    alert('Error adding product to cart.');
                }
            })
            .catch(error => console.error('Error:', error));
        }

        function filterProducts(categoryId) {
            fetch(`products.php?category=${categoryId}`)
                .then(response => response.text())
                .then(data => {
                    document.querySelector('.product-grid').innerHTML = data;
                });
        }
    </script>
</body>
</html>