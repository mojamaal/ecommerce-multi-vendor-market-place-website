<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user = $conn->query("SELECT * FROM users WHERE id = {$_SESSION['user_id']}")->fetch_assoc();
$orders = $conn->query("SELECT * FROM orders WHERE user_id = {$_SESSION['user_id']} ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
$addresses = $conn->query("SELECT * FROM addresses WHERE user_id = {$_SESSION['user_id']}")->fetch_all(MYSQLI_ASSOC);
$wishlist = $conn->query("SELECT p.*, pi.image_path FROM wishlist w JOIN products p ON w.product_id = p.id LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_main = 1 WHERE w.user_id = {$_SESSION['user_id']}")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - Greatdealz</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="account-page container">
        <h2>My Account</h2>
        <div class="account-grid">
            <div class="account-section">
                <h3>Personal Information</h3>
                <form method="post" action="update-account.php">
                    <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
                    <input type="text" name="first_name" value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
                    <input type="text" name="last_name" value="<?php echo htmlspecialchars($user['last_name']); ?>"iiiiiiii required>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    <button type="submit" class="action-button">Update</button>
                </form>
            </div>
            <div class="account-section">
                <h3>Recent Orders</h3>
                <?php if (empty($orders)): ?>
                    <p>No recent orders.</p>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <div class="order-item">
                            <p>Order #<?php echo $order['id']; ?> - <?php echo ucfirst($order['status']); ?></p>
                            <p>Total: <?php echo CURRENCY . ' ' . number_format($order['total_amount'], 2); ?></p>
                            <a href="order-tracking.php?id=<?php echo $order['id']; ?>" class="view-details">Track</a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="account-section">
                <h3>Address Book</h3>
                <?php if (empty($addresses)): ?>
                    <p>No addresses saved.</p>
                <?php else: ?>
                    <?php foreach ($addresses as $address): ?>
                        <div class="address-item">
                            <p><?php echo htmlspecialchars($address['address_line1'] . ', ' . $address['city'] . ', ' . $address['country']); ?></p>
                            <p>Type: <?php echo ucfirst($address['address_type']); ?></p>
                            <a href="edit-address.php?id=<?php echo $address['id']; ?>" class="action-button">Edit</a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                <a href="add-address.php" class="action-button">Add New Address</a>
            </div>
            <div class="account-section">
                <h3>Wishlist</h3>
                <?php if (empty($wishlist)): ?>
                    <p>Your wishlist is empty.</p>
                <?php else: ?>
                    <div class="product-grid">
                        <?php foreach ($wishlist as $item): ?>
                            <div class="product-card">
                                <img src="<?php echo $item['image_path'] ?: 'assets/images/placeholder.jpg'; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                <p><?php echo CURRENCY . ' ' . number_format($item['price'], 2); ?></p>
                                <a href="product-details.php?id=<?php echo $item['id']; ?>" class="view-details">View Details</a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>