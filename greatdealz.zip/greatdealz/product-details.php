<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Session already started in config.php, no need to call session_start() here

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$product = getProductById($product_id);
$images = getProductImages($product_id);
$related_products = getProducts($product['category_id'], 4);
$reviews = $conn->query("SELECT r.*, u.first_name FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.product_id = $product_id ORDER BY r.created_at DESC")->fetch_all(MYSQLI_ASSOC);

// Handle review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $rating = (int)$_POST['rating'];
        $comment = mysqli_real_escape_string($conn, $_POST['comment']);
        $created_at = date('Y-m-d H:i:s');

        $stmt = $conn->prepare("INSERT INTO reviews (product_id, user_id, rating, comment, created_at) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iiiss", $product_id, $user_id, $rating, $comment, $created_at);
        if ($stmt->execute()) {
            // Update average rating
            $result = $conn->query("SELECT AVG(rating) as avg_rating FROM reviews WHERE product_id = $product_id");
            $avg_rating = $result->fetch_assoc()['avg_rating'] ?: 0.0;
            $conn->query("UPDATE products SET average_rating = $avg_rating WHERE id = $product_id");
            header("Location: product-details.php?id=$product_id");
            exit;
        }
    } else {
        $error = "Please log in to submit a review.";
    }
}

// Handle review update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_review'])) {
    if (isset($_SESSION['user_id'])) {
        $review_id = (int)$_POST['review_id'];
        $rating = (int)$_POST['rating'];
        $comment = mysqli_real_escape_string($conn, $_POST['comment']);
        $user_id = $_SESSION['user_id'];

        // Verify the review belongs to the user
        $stmt = $conn->prepare("UPDATE reviews SET rating = ?, comment = ? WHERE id = ? AND user_id = ?");
        $stmt->bind_param("isii", $rating, $comment, $review_id, $user_id);
        if ($stmt->execute()) {
            // Update average rating
            $result = $conn->query("SELECT AVG(rating) as avg_rating FROM reviews WHERE product_id = $product_id");
            $avg_rating = $result->fetch_assoc()['avg_rating'] ?: 0.0;
            $conn->query("UPDATE products SET average_rating = $avg_rating WHERE id = $product_id");
            header("Location: product-details.php?id=$product_id");
            exit;
        }
    }
}

// Handle review deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_review'])) {
    if (isset($_SESSION['user_id'])) {
        $review_id = (int)$_POST['review_id'];
        $user_id = $_SESSION['user_id'];

        // Verify the review belongs to the user
        $stmt = $conn->prepare("DELETE FROM reviews WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $review_id, $user_id);
        if ($stmt->execute()) {
            // Update average rating
            $result = $conn->query("SELECT AVG(rating) as avg_rating FROM reviews WHERE product_id = $product_id");
            $avg_rating = $result->fetch_assoc()['avg_rating'] ?: 0.0;
            $conn->query("UPDATE products SET average_rating = $avg_rating WHERE id = $product_id");
            header("Location: product-details.php?id=$product_id");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - Greatdealz</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
    <style>
        .breadcrumb {
            padding: 10px 20px;
            background: #f3f4f6;
            margin-bottom: 20px;
        }
        .breadcrumb a {
            color: #6B7280;
            text-decoration: none;
            margin-right: 5px;
        }
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        .product-details {
            padding: 40px 0;
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
        }
        .product-main {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            width: 100%;
        }
        .product-images {
            flex: 1;
            min-width: 300px;
        }
        .swiper {
            width: 100%;
            height: 400px;
        }
        .swiper-slide img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .swiper-button-prev, .swiper-button-next {
            color: #FF6F61;
        }
        .swiper-pagination-bullet {
            background: #6B7280;
        }
        .swiper-pagination-bullet-active {
            background: #FF6F61;
        }
        .product-info {
            flex: 2;
            min-width: 300px;
        }
        .product-info h1 {
            font-size: 2.2rem;
            color: #374151;
            margin-bottom: 15px;
        }
        .price {
            font-size: 1.8rem;
            color: #FF6F61;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .availability {
            font-size: 1rem;
            color: #6B7280;
            margin-bottom: 20px;
        }
        .quantity {
            margin: 20px 0;
        }
        .quantity label {
            margin-right: 10px;
        }
        .quantity input {
            width: 80px;
            padding: 8px;
            margin-right: 10px;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
            margin: 20px 0;
        }
        .rating-summary {
            margin: 20px 0;
            color: #6B7280;
        }
        .rating-summary .stars {
            color: #FFD700;
            margin-left: 5px;
        }
        .social-share {
            margin: 20px 0;
        }
        .social-share a {
            color: #6B7280;
            margin-right: 15px;
            font-size: 1.2rem;
            transition: color 0.3s;
        }
        .social-share a:hover {
            color: #FF6F61;
        }
        .product-tabs {
            margin-top: 40px; /* Increased spacing between social share and tabs */
            border-bottom: 1px solid #d1d5db;
        }
        .tab-button {
            background: #fff;
            border: 1px solid #d1d5db;
            border-bottom: none;
            padding: 10px 20px;
            margin-right: 5px;
            cursor: pointer;
            border-radius: 5px 5px 0 0;
            transition: background 0.3s, color 0.3s;
        }
        .tab-button.active {
            background: #FF6F61;
            color: #fff;
            border-color: #FF6F61;
        }
        .tab-button:not(.active) {
            background: #fff;
            color: #374151;
        }
        .tab-content {
            display: none;
            padding: 20px;
            border: 1px solid #d1d5db;
            border-top: none;
            border-radius: 0 0 5px 5px;
            background: #fff;
            margin-top: -1px;
        }
        .tab-content.active {
            display: block;
        }
        .review-form {
            margin: 20px 0;
            background: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }
        .review-form .error {
            color: #FF6F61;
            margin-bottom: 10px;
        }
        .review-form label {
            display: block;
            margin-bottom: 5px;
        }
        .review-form select, .review-form textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px; /* Increased spacing between input fields */
            border: 1px solid #d1d5db;
            border-radius: 5px;
        }
        .review-form textarea {
            height: 100px;
            resize: vertical;
        }
        .review-form button {
            margin-top: 20px; /* Increased spacing between input fields and submit button */
        }
        .reviews h2, .related-products h2 {
            font-size: 1.8rem;
            color: #374151;
            margin-bottom: 20px;
        }
        .review {
            background: #fff;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            position: relative;
        }
        .review-actions {
            margin-top: 10px;
            display: flex;
            gap: 10px;
        }
        .review-actions button {
            background: none;
            border: none;
            color: #FF6F61;
            cursor: pointer;
            text-decoration: underline;
        }
        .edit-form {
            margin-top: 10px;
            padding: 10px;
            border: 1px solid #d1d5db;
            border-radius: 5px;
        }
        .edit-form select, .edit-form textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #d1d5db;
            border-radius: 5px;
        }
        .edit-form textarea {
            height: 80px;
            resize: vertical;
        }
        @media (max-width: 768px) {
            .product-main {
                flex-direction: column;
            }
            .product-images, .product-info {
                width: 100%;
            }
            .swiper {
                height: 300px;
            }
            .action-buttons {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="breadcrumb">
        <a href="index.php">Home</a> > <a href="products.php">Products</a> > <?php echo htmlspecialchars($product['name']); ?>
    </div>
    
    <section class="product-details container">
        <div class="product-main">
            <div class="product-images">
                <div class="swiper mySwiper">
                    <div class="swiper-wrapper">
                        <?php foreach ($images as $image): ?>
                            <div class="swiper-slide">
                                <img src="<?php echo $image['image_path']; ?>" alt="Product Image">
                            </div>
                        <?php endforeach; ?>
                        <?php if (empty($images)): ?>
                            <div class="swiper-slide">
                                <img src="<?php echo $product['main_image'] ?: 'assets/images/placeholder.jpg'; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
            <div class="product-info">
                <h1><?php echo htmlspecialchars($product['name']); ?></h1>
                <p class="price"><?php echo CURRENCY . ' ' . number_format($product['price'], 2); ?></p>
                <p class="availability"><?php echo $product['stock_quantity'] > 0 ? 'In Stock' : 'Out of Stock'; ?></p>
                <div class="rating-summary">
                    Average Rating: <?php echo $product['average_rating'] ?: '0.0'; ?> <span class="stars"><?php echo str_repeat('★', round($product['average_rating'] ?: 0)); ?></span> (<?php echo count($reviews); ?> reviews)
                </div>
                <div class="quantity">
                    <label for="quantity">Quantity:</label>
                    <input type="number" id="quantity" name="quantity" value="1" min="1" max="<?php echo $product['stock_quantity']; ?>" <?php echo $product['stock_quantity'] <= 0 ? 'disabled' : ''; ?>>
                </div>
                <div class="action-buttons">
                    <button type="submit" class="add-to-cart" onclick="addToCart(<?php echo $product['id']; ?>, document.getElementById('quantity').value)" <?php echo $product['stock_quantity'] <= 0 ? 'disabled' : ''; ?>>Add to Cart</button>
                    <a href="checkout.php?product_id=<?php echo $product_id; ?>" class="action-button" <?php echo $product['stock_quantity'] <= 0 ? 'disabled' : ''; ?>>Buy Now</a>
                </div>
                <div class="social-share">
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']); ?>" target="_blank"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                </div>
                <div class="product-tabs">
                    <button class="tab-button active" onclick="openTab('description')">Description</button>
                    <button class="tab-button" onclick="openTab('specifications')">Specifications</button>
                    <div id="description" class="tab-content active"><?php echo nl2br(htmlspecialchars($product['description'])); ?></div>
                    <div id="specifications" class="tab-content"><?php echo nl2br(htmlspecialchars($product['specifications'])); ?></div>
                </div>
            </div>
        </div>
        
        <div class="reviews">
            <h2>Customer Reviews</h2>
            <?php if (!empty($error)): ?>
                <p class="error"><?php echo $error; ?></p>
            <?php endif; ?>
            <div class="review-form">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <form method="POST" action="">
                        <label for="rating">Rating:</label>
                        <select id="rating" name="rating" required>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                        <label for="comment">Comment:</label>
                        <textarea id="comment" name="comment" placeholder="Write your review..." required></textarea>
                        <button type="submit" name="submit_review" class="action-button">Submit Review</button>
                    </form>
                <?php else: ?>
                    <p>Please <a href="login.php">log in</a> to submit a review.</p>
                <?php endif; ?>
            </div>
            <?php if (empty($reviews)): ?>
                <p>No reviews yet.</p>
            <?php else: ?>
                <?php foreach ($reviews as $review): ?>
                    <div class="review">
                        <p><strong><?php echo htmlspecialchars($review['first_name']); ?></strong> - <?php echo str_repeat('★', $review['rating']); ?> <span class="date"><?php echo date('F d, Y', strtotime($review['created_at'])); ?></span></p>
                        <p><?php echo nl2br(htmlspecialchars($review['comment'])); ?></p>
                        <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $review['user_id']): ?>
                            <div class="review-actions">
                                <button onclick="toggleEditForm(<?php echo $review['id']; ?>)">Edit</button>
                                <form method="POST" action="" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this review?');">
                                    <input type="hidden" name="review_id" value="<?php echo $review['id']; ?>">
                                    <button type="submit" name="delete_review">Delete</button>
                                </form>
                            </div>
                            <div class="edit-form" id="edit-form-<?php echo $review['id']; ?>" style="display:none;">
                                <form method="POST" action="">
                                    <input type="hidden" name="review_id" value="<?php echo $review['id']; ?>">
                                    <label for="edit-rating-<?php echo $review['id']; ?>">Rating:</label>
                                    <select id="edit-rating-<?php echo $review['id']; ?>" name="rating" required>
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <option value="<?php echo $i; ?>" <?php echo $i == $review['rating'] ? 'selected' : ''; ?>><?php echo $i; ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <label for="edit-comment-<?php echo $review['id']; ?>">Comment:</label>
                                    <textarea id="edit-comment-<?php echo $review['id']; ?>" name="comment" required><?php echo htmlspecialchars($review['comment']); ?></textarea>
                                    <button type="submit" name="update_review" class="action-button">Update Review</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="related-products">
            <h2>Related Products</h2>
            <div class="product-grid">
                <?php foreach ($related_products as $related): ?>
                    <div class="product-card">
                        <img src="<?php echo $related['image_path'] ?: 'assets/images/placeholder.jpg'; ?>" alt="<?php echo htmlspecialchars($related['name']); ?>">
                        <h3><?php echo htmlspecialchars($related['name']); ?></h3>
                        <p><?php echo CURRENCY . ' ' . number_format($related['price'], 2); ?></p>
                        <a href="product-details.php?id=<?php echo $related['id']; ?>" class="view-details">View Details</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
        var swiper = new Swiper('.mySwiper', {
            spaceBetween: 10,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
            loop: true,
        });

        function openTab(tabId) {
            // Remove active class from all tab contents and buttons
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
            // Add active class to the selected tab content and button
            document.getElementById(tabId).classList.add('active');
            event.target.classList.add('active');
        }

        function toggleEditForm(reviewId) {
            const form = document.getElementById('edit-form-' + reviewId);
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        }
    </script>
</body>
</html>