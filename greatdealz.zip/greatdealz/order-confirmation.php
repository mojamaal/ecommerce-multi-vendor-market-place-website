<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $order_id, $_SESSION['user_id']);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header('Location: account.php');
    exit;
}

// Secure query for order items using prepared statement
$stmt = $conn->prepare("SELECT oi.*, p.name, pi.image_path FROM order_items oi JOIN products p ON oi.product_id = p.id LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_main = 1 WHERE oi.order_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch customer details
$stmt = $conn->prepare("SELECT first_name, last_name, email FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();

// Decode shipping and billing addresses
$shipping_address = json_decode($order['shipping_address'], true);
$billing_address = json_decode($order['billing_address'], true);

// Send confirmation email using PHPMailer
require_once 'includes/PHPMailer/src/PHPMailer.php';
require_once 'includes/PHPMailer/src/Exception.php';
require_once 'includes/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$to = $customer['email'];
$subject = "Order Confirmation - Greatdealz #$order_id";
$message = "Thank you for your order! Order #$order_id has been placed. Estimated delivery: " . $order['estimated_delivery'];

$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // Gmail's SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = 'your-email@gmail.com'; // Replace with your Gmail address
    $mail->Password = 'your-app-password'; // Replace with your Gmail App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // Recipients
    $mail->setFrom('your-email@gmail.com', 'Greatdealz');
    $mail->addAddress($to);

    // Content
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = nl2br($message); // Convert newlines to <br> for HTML
    $mail->AltBody = $message; // Plain text version

    $mail->send();
    error_log("Order confirmation email sent to $to for order #$order_id");
} catch (Exception $e) {
    error_log("Failed to send email to $to for order #$order_id. Error: {$mail->ErrorInfo}");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - Greatdealz</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
    <style>
        .order-confirmation {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        .order-confirmation h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        .order-confirmation p {
            text-align: center;
            color: #555;
        }
        .order-details {
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
        }
        .order-details-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .order-details-header h3 {
            font-size: 24px;
            color: #333;
            margin: 0;
        }
        .order-details-header p {
            color: #777;
            margin: 5px 0;
        }
        .customer-info, .address-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .customer-info div, .address-info div {
            width: 48%;
        }
        .customer-info h4, .address-info h4 {
            font-size: 16px;
            color: #333;
            margin-bottom: 10px;
        }
        .customer-info p, .address-info p {
            color: #555;
            margin: 5px 0;
            text-align: left;
        }
        .order-items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .order-items-table th, .order-items-table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        .order-items-table th {
            background-color: #f1f1f1;
            font-weight: bold;
            color: #333;
        }
        .order-items-table td img {
            width: 50px;
            height: auto;
            vertical-align: middle;
            margin-right: 10px;
        }
        .order-items-table .total-row {
            font-weight: bold;
            background-color: #f1f1f1;
        }
        .order-details-footer {
            text-align: center;
            color: #777;
            margin-top: 20px;
        }
        .action-buttons {
            text-align: center;
            margin-top: 30px;
        }
        .action-buttons a, .action-buttons button {
            display: inline-block;
            padding: 10px 20px;
            margin: 0 10px;
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .action-buttons a.continue-shopping {
            background-color: #28a745;
        }
        .action-buttons button.print-receipt {
            background-color: #6c757d;
        }

        /* Print styles */
        @media print {
            body * {
                visibility: hidden;
            }
            .order-details, .order-details * {
                visibility: visible;
            }
            .order-details {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                margin: 0;
                border: none;
                background: #fff;
            }
            .order-details-footer {
                margin-top: 20px;
            }
            /* Hide elements not needed in print */
            .order-details .action-buttons {
                display: none;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="order-confirmation container">
        <h2>Order Confirmed!</h2>
        <p>Thank you for your order. Your order number is #<?php echo $order_id; ?>.</p>
        <p>Estimated Delivery: <?php echo date('F j, Y', strtotime($order['estimated_delivery'])); ?></p>
        <div class="order-details">
            <div class="order-details-header">
                <h3>Greatdealz Order Summary</h3>
                <p>Order #<?php echo $order_id; ?> | Placed on <?php echo date('F j, Y', strtotime($order['created_at'])); ?></p>
            </div>
            <div class="customer-info">
                <div>
                    <h4>Customer Details</h4>
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($customer['email']); ?></p>
                </div>
                <div>
                    <h4>Order Information</h4>
                    <p><strong>Payment Method:</strong> <?php echo ucfirst($order['payment_method']); ?></p>
                    <p><strong>Payment Status:</strong> <?php echo ucfirst($order['payment_status']); ?></p>
                </div>
            </div>
            <div class="address-info">
                <div>
                    <h4>Shipping Address</h4>
                    <p><?php echo htmlspecialchars($shipping_address['address_line1']); ?></p>
                    <?php if (!empty($shipping_address['address_line2'])): ?>
                        <p><?php echo htmlspecialchars($shipping_address['address_line2']); ?></p>
                    <?php endif; ?>
                    <p><?php
                        $city = $shipping_address['city'] ?? '';
                        $postal_code = $shipping_address['postal_code'] ?? '';
                        $address_parts = array_filter([$city, $postal_code]);
                        echo htmlspecialchars(implode(', ', $address_parts));
                    ?></p>
                    <p><?php echo htmlspecialchars($shipping_address['country']); ?></p>
                </div>
                <div>
                    <h4>Billing Address</h4>
                    <p><?php echo htmlspecialchars($billing_address['address_line1']); ?></p>
                    <?php if (!empty($billing_address['address_line2'])): ?>
                        <p><?php echo htmlspecialchars($billing_address['address_line2']); ?></p>
                    <?php endif; ?>
                    <p><?php
                        $city = $billing_address['city'] ?? '';
                        $postal_code = $billing_address['postal_code'] ?? '';
                        $address_parts = array_filter([$city, $postal_code]);
                        echo htmlspecialchars(implode(', ', $address_parts));
                    ?></p>
                    <p><?php echo htmlspecialchars($billing_address['country']); ?></p>
                </div>
            </div>
            <table class="order-items-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td>
                                <img src="<?php echo $item['image_path'] ?: 'assets/images/placeholder.jpg'; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                <?php echo htmlspecialchars($item['name']); ?>
                            </td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td><?php echo CURRENCY . ' ' . number_format($item['unit_price'], 2); ?></td>
                            <td><?php echo CURRENCY . ' ' . number_format($item['unit_price'] * $item['quantity'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="total-row">
                        <td colspan="3">Total</td>
                        <td><?php echo CURRENCY . ' ' . number_format($order['total_amount'], 2); ?></td>
                    </tr>
                </tbody>
            </table>
            <div class="order-details-footer">
                <p>Thank you for shopping with Greatdealz!</p>
                <p>Contact us at support@greatdealz.com | +123-456-7890</p>
            </div>
            <div class="action-buttons">
                <a href="order-tracking.php?id=<?php echo $order_id; ?>" class="track-order">Track Order</a>
                <a href="products.php" class="continue-shopping">Continue Shopping</a>
                <button onclick="window.print()" class="print-receipt">Print Receipt</button>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>