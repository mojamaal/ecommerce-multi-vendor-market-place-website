<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $order_id, $_SESSION['user_id']);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header('Location: account.php');
    exit;
}

$status_steps = ['pending' => 'Order Placed', 'processing' => 'Processing', 'shipped' => 'Shipped', 'delivered' => 'Delivered'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Tracking - Greatdealz</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="order-tracking container">
        <h2>Track Your Order</h2>
        <p>Order #<?php echo $order_id; ?> - Estimated Delivery: <?php echo date('F j, Y', strtotime($order['estimated_delivery'])); ?></p>
        <div class="tracking-timeline">
            <?php foreach ($status_steps as $key => $label): ?>
                <div class="timeline-step <?php echo $order['status'] == $key ? 'active' : ''; ?>">
                    <span class="step-icon"><i class="fas fa-check-circle"></i></span>
                    <p><?php echo $label; ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>