<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$cart_items = getCartItems();
if (empty($cart_items)) {
    header('Location: cart.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $shipping_address = json_encode($_POST['shipping']);
    $billing_address = isset($_POST['same_as_shipping']) ? $shipping_address : json_encode($_POST['billing']);
    $payment_method = $_POST['payment_method'];
    
    $order_id = createOrder($_SESSION['user_id'], $shipping_address, $billing_address, $payment_method);
    if ($order_id) {
        header("Location: order-confirmation.php?id=$order_id");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Greatdealz</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="checkout-page container">
        <h2>Checkout</h2>
        <div class="checkout-grid">
            <div class="checkout-forms">
                <form method="post">
                    <h3>Shipping Address</h3>
                    <input type="text" name="shipping[address_line1]" placeholder="Address Line 1" required>
                    <input type="text" name="shipping[address_line2]" placeholder="Address Line 2">
                    <input type="text" name="shipping[city]" placeholder="City" required>
                    <input type="text" name="shipping[postal_code]" placeholder="Postal Code" required>
                    <input type="text" name="shipping[country]" placeholder="Country" required>
                    
                    <label><input type="checkbox" name="same_as_shipping" checked> Billing address same as shipping</label>
                    
                    <div id="billing-address" style="display: none;">
                        <h3>Billing Address</h3>
                        <input type="text" name="billing[address_line1]" placeholder="Address Line 1">
                        <input type="text" name="billing[address_line2]" placeholder="Address Line 2">
                        <input type="text" name="billing[city]" placeholder="City">
                        <input type="text" name="billing[postal_code]" placeholder="Postal Code">
                        <input type="text" name="billing[country]" placeholder="Country">
                    </div>
                    
                    <h3>Payment Method</h3>
                    <label><input type="radio" name="payment_method" value="online" required> Online Cash Transfer</label>
                    <div id="online-details" style="display: none;">
                        <p>Bank: XYZ Bank<br>Account: 123456789<br>Branch: Colombo</p>
                    </div>
                    <label><input type="radio" name="payment_method" value="cod"> Cash on Delivery</label>
                    
                    <label><input type="checkbox" required> I agree to the Terms and Conditions</label>
                    
                    <button type="submit" class="confirm-order">Confirm Order</button>
                </form>
            </div>
            <div class="order-summary">
                <h3>Order Summary</h3>
                <?php foreach ($cart_items as $item): ?>
                    <div class="summary-item">
                        <img src="<?php echo $item['image_path'] ?: 'assets/images/placeholder.jpg'; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                        <div>
                            <p><?php echo htmlspecialchars($item['name']); ?></p>
                            <p>Qty: <?php echo $item['quantity']; ?></p>
                            <p><?php echo CURRENCY . ' ' . number_format($item['price'] * $item['quantity'], 2); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
                <p>Total: <?php
                    $total = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart_items));
                    echo CURRENCY . ' ' . number_format($total, 2);
                ?></p>
                <div class="security-badges">
                    <i class="fas fa-shield-alt"></i> Secure Checkout
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
    <script>
        document.querySelector('[name="same_as_shipping"]').addEventListener('change', function() {
            document.getElementById('billing-address').style.display = this.checked ? 'none' : 'block';
        });
        
        document.querySelectorAll('[name="payment_method"]').forEach(radio => {
            radio.addEventListener('change', function() {
                document.getElementById('online-details').style.display = this.value === 'online' ? 'block' : 'none';
            });
        });
    </script>
</body>
</html>