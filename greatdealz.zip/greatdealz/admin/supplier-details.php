<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isAdmin()) {
    header('Location: ../login.php');
    exit;
}

$supplier_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$supplier = $conn->query("SELECT * FROM suppliers WHERE id = $supplier_id")->fetch_assoc();
$products = $conn->query("SELECT sp.*, p.name FROM supplier_products sp JOIN products p ON sp.product_id = p.id WHERE sp.supplier_id = $supplier_id")->fetch_all(MYSQLI_ASSOC);
$order_history = $conn->query("SELECT oi.*, o.created_at, p.name FROM order_items oi JOIN orders o ON oi.order_id = o.id JOIN products p ON oi.product_id = p.id WHERE oi.supplier_id = $supplier_id")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Details - Greatdealz</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include '../includes/admin-header.php'; ?>
    
    <section class="supplier-details container">
        <h2>Supplier Details</h2>
        <?php if ($supplier): ?>
            <div class="supplier-info">
                <h3><?php echo htmlspecialchars($supplier['name']); ?></h3>
                <p>Email: <?php echo htmlspecialchars($supplier['contact_email']); ?></p>
                <p>Phone: <?php echo htmlspecialchars($supplier['phone'] ?: '-'); ?></p>
                <p>Address: <?php echo htmlspecialchars($supplier['address'] ?: '-'); ?></p>
            </div>
            <div class="product-catalog">
                <h3>Product Catalog</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Cost Price (LKR)</th>
                            <th>Initial Stock</th>
                            <th>Current Stock</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($product['name']); ?></td>
                                <td><?php echo CURRENCY . ' ' . number_format($product['cost_price'], 2); ?></td>
                                <td><?php echo $product['initial_stock_quantity']; ?></td>
                                <td><?php echo $product['stock_quantity']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="order-history">
                <h3>Order History</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit Price (LKR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($order_history as $item): ?>
                            <tr>
                                <td><?php echo $item['order_id']; ?></td>
                                <td><?php echo date('Y-m-d', strtotime($item['created_at'])); ?></td>
                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td><?php echo CURRENCY . ' ' . number_format($item['unit_price'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p>Supplier not found.</p>
        <?php endif; ?>
    </section>
    
    <?php include '../includes/admin-footer.php'; ?>
    <script src="../assets/js/admin.js"></script>
</body>
</html>