<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isAdmin()) {
    header('Location: ../login.php');
    exit;
}

$products = $conn->query("SELECT p.*, c.name AS category_name, s.name AS supplier_name 
                        FROM products p 
                        LEFT JOIN categories c ON p.category_id = c.id 
                        LEFT JOIN suppliers s ON p.supplier_id = s.id")->fetch_all(MYSQLI_ASSOC);
$categories = $conn->query("SELECT * FROM categories")->fetch_all(MYSQLI_ASSOC);
$suppliers = $conn->query("SELECT * FROM suppliers")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $specifications = mysqli_real_escape_string($conn, $_POST['specifications']);
    $price = (float)$_POST['price'];
    $stock_quantity = (int)$_POST['stock_quantity'];
    $initial_stock_quantity = $stock_quantity;
    $category_id = (int)$_POST['category_id'];
    $brand = mysqli_real_escape_string($conn, $_POST['brand']);
    $status = $_POST['status'];
    $supplier_id = (int)$_POST['supplier_id'];

    $upload_dir = __DIR__ . '/../assets/images/products/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    $main_image = 'assets/images/placeholder.jpg';
    if (isset($_FILES['main_image']) && $_FILES['main_image']['error'] == UPLOAD_ERR_OK) {
        $main_image_name = time() . '_' . basename($_FILES['main_image']['name']);
        $main_image_path = $upload_dir . $main_image_name;
        $main_image_db_path = 'assets/images/products/' . $main_image_name;
        if (move_uploaded_file($_FILES['main_image']['tmp_name'], $main_image_path)) {
            $main_image = $main_image_db_path;
        }
    }

    $stmt = $conn->prepare("INSERT INTO products (name, description, specifications, price, stock_quantity, initial_stock_quantity, category_id, brand, main_image, status, supplier_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdiissssi", $name, $description, $specifications, $price, $stock_quantity, $initial_stock_quantity, $category_id, $brand, $main_image, $status, $supplier_id);
    if ($stmt->execute()) {
        $product_id = $conn->insert_id;

        if ($main_image !== 'assets/images/placeholder.jpg') {
            $stmt = $conn->prepare("INSERT INTO product_images (product_id, image_path, is_main) VALUES (?, ?, 1)");
            $stmt->bind_param("is", $product_id, $main_image);
            $stmt->execute();
        }

        if (isset($_FILES['additional_images']) && !empty($_FILES['additional_images']['name'][0])) {
            $files = $_FILES['additional_images'];
            $total_images = count($files['name']);
            $max_images = min($total_images, 5);
            for ($i = 0; $i < $max_images; $i++) {
                if ($files['error'][$i] == UPLOAD_ERR_OK) {
                    $image_name = time() . '_' . $i . '_' . basename($files['name'][$i]);
                    $image_path = $upload_dir . $image_name;
                    $image_db_path = 'assets/images/products/' . $image_name;
                    if (move_uploaded_file($files['tmp_name'][$i], $image_path)) {
                        $stmt = $conn->prepare("INSERT INTO product_images (product_id, image_path, is_main) VALUES (?, ?, 0)");
                        $stmt->bind_param("is", $product_id, $image_db_path);
                        $stmt->execute();
                    }
                }
            }
        }

        if (isset($_POST['suppliers']) && is_array($_POST['suppliers'])) {
            foreach ($_POST['suppliers'] as $supp_id => $data) {
                if (isset($data['selected']) && $data['selected'] == '1') {
                    $cost_price = (float)$data['cost_price'];
                    $supplier_quantity = (int)$data['quantity'];
                    $supplier_initial_quantity = $supplier_quantity;
                    $stmt = $conn->prepare("INSERT INTO supplier_products (supplier_id, product_id, cost_price, stock_quantity, initial_stock_quantity) VALUES (?, ?, ?, ?, ?)");
                    $stmt->bind_param("iiddi", $supp_id, $product_id, $cost_price, $supplier_quantity, $supplier_initial_quantity);
                    $stmt->execute();
                }
            }
        }

        header('Location: products.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Greatdealz</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-header.php'; ?>
    
    <nav class="admin-nav">
        <div class="nav-container">
            <div class="nav-logo">Greatdealz Admin</div>
            <div class="nav-links">
                <a href="index.php">Dashboard</a>
                <a href="products.php">Products</a>
                <a href="orders.php">Orders</a>
                <a href="customers.php">Customers</a>
                <a href="categories.php">Categories</a>
                <a href="featured.php">Featured</a>
                <a href="suppliers.php">Suppliers</a>
                <a href="settings.php">Settings</a>
                <a href="../logout.php">Logout</a>
            </div>
        </div>
    </nav>
    
    <section class="admin-products container">
        <h2>Manage Products</h2>
        <form method="post" class="add-product-form" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
            <div class="form-group">
                <label for="name">Product Name</label>
                <input type="text" id="name" name="name" placeholder="Enter product name" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" placeholder="Enter description" required></textarea>
            </div>
            <div class="form-group">
                <label for="specifications">Specifications</label>
                <textarea id="specifications" name="specifications" placeholder="Enter specifications"></textarea>
            </div>
            <div class="form-group">
                <label for="price">Price (LKR)</label>
                <input type="number" id="price" name="price" placeholder="Enter price" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="stock_quantity">Stock Quantity</label>
                <input type="number" id="stock_quantity" name="stock_quantity" placeholder="Enter stock quantity" required>
            </div>
            <div class="form-group">
                <label for="category_id">Category</label>
                <select id="category_id" name="category_id" required>
                    <option value="">Select Category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="brand">Brand</label>
                <input type="text" id="brand" name="brand" placeholder="Enter brand name" required>
            </div>
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status" required>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <div class="form-group">
                <label for="supplier_id">Primary Supplier</label>
                <select id="supplier_id" name="supplier_id">
                    <option value="">Select Supplier</option>
                    <?php foreach ($suppliers as $sup): ?>
                        <option value="<?php echo $sup['id']; ?>"><?php echo htmlspecialchars($sup['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="main_image">Main Image</label>
                <input type="file" id="main_image" name="main_image" accept="image/*" required>
            </div>
            <div class="form-group">
                <label for="additional_images">Additional Images (up to 5)</label>
                <input type="file" id="additional_images" name="additional_images[]" accept="image/*" multiple>
                <small class="form-text">You can upload up to 5 additional images.</small>
            </div>
            <h3>Assign Suppliers</h3>
            <?php foreach ($suppliers as $sup): ?>
                <div class="supplier-row form-group">
                    <label>
                        <input type="checkbox" name="suppliers[<?php echo $sup['id']; ?>][selected]" value="1">
                        <?php echo htmlspecialchars($sup['name']); ?>
                    </label>
                    <input type="number" name="suppliers[<?php echo $sup['id']; ?>][cost_price]" placeholder="Cost Price (LKR)" step="0.01">
                    <input type="number" name="suppliers[<?php echo $sup['id']; ?>][quantity]" placeholder="Quantity">
                </div>
            <?php endforeach; ?>
            <div class="form-group">
                <button type="submit" name="add_product" class="action-button">Add Product</button>
            </div>
        </form>
        <div class="product-list">
            <h3>Product List</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Price (LKR)</th>
                        <th>Initial Stock</th>
                        <th>Current Stock</th>
                        <th>Supplier</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?php echo $product['id']; ?></td>
                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                            <td><?php echo htmlspecialchars($product['category_name'] ?: 'Uncategorized'); ?></td>
                            <td><?php echo CURRENCY . ' ' . number_format($product['price'], 2); ?></td>
                            <td><?php echo $product['initial_stock_quantity']; ?></td>
                            <td><?php echo $product['stock_quantity']; ?></td>
                            <td><?php echo htmlspecialchars($product['supplier_name'] ?: '-'); ?></td>
                            <td><?php echo ucfirst($product['status']); ?></td>
                            <td>
                                <a href="edit-product.php?id=<?php echo $product['id']; ?>" class="action-button">Edit</a>
                                <a href="delete-product.php?id=<?php echo $product['id']; ?>" class="action-button" onclick="return confirm('Are you sure?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
    
    <?php include __DIR__ . '/../includes/admin-footer.php'; ?>
    <script src="<?php echo SITE_URL; ?>assets/js/admin.js"></script>
</body>
</html>