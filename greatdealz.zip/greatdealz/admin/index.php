<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isAdmin()) {
    header('Location: ../login.php');
    exit;
}

$total_sales = $conn->query("SELECT SUM(total_amount) FROM orders WHERE payment_status = 'completed'")->fetch_row()[0] ?? 0;
$total_orders = $conn->query("SELECT COUNT(*) FROM orders")->fetch_row()[0];
$total_customers = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetch_row()[0];
$pending_orders = $conn->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetch_row()[0];

// Calculate total profit
$total_profit_query = "SELECT SUM((oi.unit_price - sp.cost_price) * oi.quantity) AS total_profit
                      FROM order_items oi
                      JOIN orders o ON oi.order_id = o.id
                      JOIN supplier_products sp ON oi.supplier_id = sp.supplier_id AND oi.product_id = sp.product_id
                      WHERE o.payment_status = 'completed'";
$total_profit = $conn->query($total_profit_query)->fetch_row()[0] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Greatdealz</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-header.php'; ?>
    
    <section class="admin-dashboard container">
        <h2>Admin Dashboard</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Sales</h3>
                <p><?php echo CURRENCY . ' ' . number_format($total_sales, 2); ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Profit</h3>
                <p><?php echo CURRENCY . ' ' . number_format($total_profit, 2); ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Orders</h3>
                <p><?php echo $total_orders; ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Customers</h3>
                <p><?php echo $total_customers; ?></p>
            </div>
            <div class="stat-card">
                <h3>Pending Orders</h3>
                <p><?php echo $pending_orders; ?></p>
            </div>
        </div>
        <div class="quick-actions">
            <h3>Quick Actions</h3>
            <a href="<?php echo SITE_URL; ?>admin/products.php" class="action-button">Manage Products</a>
            <a href="<?php echo SITE_URL; ?>admin/orders.php" class="action-button">View Orders</a>
            <a href="<?php echo SITE_URL; ?>admin/customers.php" class="action-button">Manage Customers</a>
            <a href="<?php echo SITE_URL; ?>admin/suppliers.php" class="action-button">Manage Suppliers</a>
        </div>
    </section>
    
    <?php include __DIR__ . '/../includes/admin-footer.php'; ?>
    <script src="<?php echo SITE_URL; ?>assets/js/admin.js"></script>
</body>
</html>