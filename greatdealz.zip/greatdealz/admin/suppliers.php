<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isAdmin()) {
    header('Location: ../login.php');
    exit;
}

$suppliers = [];
$error_message = '';
try {
    $stmt = $conn->prepare("SELECT * FROM suppliers");
    if ($stmt) {
        $stmt->execute();
        $suppliers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
} catch (Exception $e) {
    $error_message = "Error fetching suppliers: " . $e->getMessage();
    error_log($error_message);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_supplier'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $contact_email = mysqli_real_escape_string($conn, $_POST['contact_email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $bank_name = mysqli_real_escape_string($conn, $_POST['bank_name']);
    $account_number = mysqli_real_escape_string($conn, $_POST['account_number']);
    $account_holder = mysqli_real_escape_string($conn, $_POST['account_holder']);
    $ifsc_code = mysqli_real_escape_string($conn, $_POST['ifsc_code']);
    if (registerSupplier($name, $contact_email, $phone, $address, $bank_name, $account_number, $account_holder, $ifsc_code)) {
        header('Location: suppliers.php');
        exit;
    } else {
        $error_message = "Failed to add supplier. Please try again.";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['approve_supplier'])) {
    $supplier_id = (int)$_POST['supplier_id'];
    $stmt = $conn->prepare("UPDATE suppliers SET status = 'approved' WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $supplier_id);
        $stmt->execute();
        $stmt->close();
        header('Location: suppliers.php');
        exit;
    } else {
        $error_message = "Failed to approve supplier: " . $conn->error;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_supplier'])) {
    $supplier_id = (int)$_POST['supplier_id'];
    $stmt = $conn->prepare("DELETE s, sb FROM suppliers s 
                           LEFT JOIN supplier_bank_details sb ON s.id = sb.supplier_id 
                           WHERE s.id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $supplier_id);
        $stmt->execute();
        $stmt->close();
        header('Location: suppliers.php');
        exit;
    } else {
        $error_message = "Failed to delete supplier: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Suppliers - Greatdealz</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/fonts/fontawesome/css/all.min.css">
    <style>
        .add-supplier-form { max-width: 600px; margin-bottom: 20px; }
        .supplier-list table { width: 100%; border-collapse: collapse; }
        .supplier-list th, .supplier-list td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        .supplier-list th { background-color: #f4f4f4; }
        .action-button { padding: 8px 16px; margin: 5px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; }
        .form-group input, .form-group textarea { width: 100%; padding: 8px; box-sizing: border-box; }
        .error { color: #FF6F61; font-weight: bold; margin-bottom: 15px; }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-header.php'; ?>
    
    <section class="admin-suppliers container">
        <h2>Manage Suppliers</h2>
        <?php if ($error_message): ?>
            <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>
        <form method="post" class="add-supplier-form">
            <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
            <div class="form-group">
                <label for="name">Supplier Name</label>
                <input type="text" id="name" name="name" placeholder="Enter supplier name" required>
            </div>
            <div class="form-group">
                <label for="contact_email">Contact Email</label>
                <input type="email" id="contact_email" name="contact_email" placeholder="Enter contact email" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="text" id="phone" name="phone" placeholder="Enter phone">
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" placeholder="Enter address"></textarea>
            </div>
            <div class="form-group">
                <label for="bank_name">Bank Name</label>
                <input type="text" id="bank_name" name="bank_name" placeholder="Enter bank name" required>
            </div>
            <div class="form-group">
                <label for="account_number">Account Number</label>
                <input type="text" id="account_number" name="account_number" placeholder="Enter account number" required>
            </div>
            <div class="form-group">
                <label for="account_holder">Account Holder</label>
                <input type="text" id="account_holder" name="account_holder" placeholder="Enter account holder name" required>
            </div>
            <div class="form-group">
                <label for="ifsc_code">IFSC Code</label>
                <input type="text" id="ifsc_code" name="ifsc_code" placeholder="Enter IFSC code" required>
            </div>
            <div class="form-group">
                <button type="submit" name="add_supplier" class="action-button">Add Supplier</button>
            </div>
        </form>
        <div class="supplier-list">
            <h3>Supplier List</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($suppliers)): ?>
                        <tr><td colspan="6">No suppliers found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($suppliers as $supplier): ?>
                            <tr>
                                <td><?php echo $supplier['id']; ?></td>
                                <td><?php echo htmlspecialchars($supplier['name']); ?></td>
                                <td><?php echo htmlspecialchars($supplier['contact_email']); ?></td>
                                <td><?php echo htmlspecialchars($supplier['phone'] ?: '-'); ?></td>
                                <td><?php echo ucfirst($supplier['status'] ?: 'pending'); ?></td>
                                <td>
                                    <a href="supplier-details.php?id=<?php echo $supplier['id']; ?>" class="action-button">View Details</a>
                                    <?php if ($supplier['status'] === 'pending'): ?>
                                        <form method="post" style="display:inline;">
                                            <input type="hidden" name="supplier_id" value="<?php echo $supplier['id']; ?>">
                                            <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
                                            <button type="submit" name="approve_supplier" class="action-button">Approve</button>
                                        </form>
                                    <?php endif; ?>
                                    <form method="post" style="display:inline;">
                                        <input type="hidden" name="supplier_id" value="<?php echo $supplier['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
                                        <button type="submit" name="delete_supplier" class="action-button" onclick="return confirm('Are you sure?');">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
    
    <?php include __DIR__ . '/../includes/admin-footer.php'; ?>
    <script src="<?php echo SITE_URL; ?>assets/js/admin.js"></script>
</body>
</html>