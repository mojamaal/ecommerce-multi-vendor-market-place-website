<?php
  require_once __DIR__ . '/../includes/config.php';
  require_once __DIR__ . '/../includes/functions.php';

  if (!isAdmin()) {
      header('Location: ../login.php');
      exit;
  }

  $categories = $conn->query("SELECT * FROM categories")->fetch_all(MYSQLI_ASSOC);

  if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
      $name = mysqli_real_escape_string($conn, $_POST['name']);
      $parent_id = $_POST['parent_id'] ? (int)$_POST['parent_id'] : null;
      $stmt = $conn->prepare("INSERT INTO categories (name, parent_id) VALUES (?, ?)");
      $stmt->bind_param("si", $name, $parent_id);
      $stmt->execute();
      header('Location: categories.php');
      exit;
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_category'])) {
      $category_id = (int)$_POST['category_id'];
      $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
      $stmt->bind_param("i", $category_id);
      $stmt->execute();
      header('Location: categories.php');
      exit;
  }
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Manage Categories - Greatdealz</title>
      <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
      <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/fonts/fontawesome/css/all.min.css">
  </head>
  <body>
      <?php include __DIR__ . '/../includes/admin-header.php'; ?>
      
      <section class="admin-categories container">
          <h2>Manage Categories</h2>
          <form method="post" class="add-category-form">
              <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
              <div class="form-group">
                  <label for="name">Category Name</label>
                  <input type="text" id="name" name="name" placeholder="Enter category name" required>
              </div>
              <div class="form-group">
                  <label for="parent_id">Parent Category</label>
                  <select id="parent_id" name="parent_id">
                      <option value="">No Parent</option>
                      <?php foreach ($categories as $category): ?>
                          <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                      <?php endforeach; ?>
                  </select>
              </div>
              <div class="form-group">
                  <button type="submit" name="add_category" class="action-button">Add Category</button>
              </div>
          </form>
          <div class="category-list">
              <h3>Category List</h3>
              <table>
                  <thead>
                      <tr>
                          <th>ID</th>
                          <th>Name</th>
                          <th>Parent</th>
                          <th>Actions</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($categories as $category): ?>
                          <tr>
                              <td><?php echo $category['id']; ?></td>
                              <td><?php echo htmlspecialchars($category['name']); ?></td>
                              <td><?php
                                  if ($category['parent_id']) {
                                      $parent = $conn->query("SELECT name FROM categories WHERE id = {$category['parent_id']}")->fetch_assoc();
                                      echo htmlspecialchars($parent['name']);
                                  } else {
                                      echo '-';
                                  }
                              ?></td>
                              <td>
                                  <a href="edit-category.php?id=<?php echo $category['id']; ?>" class="action-button">Edit</a>
                                  <form method="post" style="display:inline;">
                                      <input type="hidden" name="category_id" value="<?php echo $category['id']; ?>">
                                      <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
                                      <button type="submit" name="delete_category" class="action-button" onclick="return confirm('Are you sure?');">Delete</button>
                                  </form>
                              </td>
                          </tr>
                      <?php endforeach; ?>
                  </tbody>
              </table>
          </div>
      </section>
      
      <?php include __DIR__ . '/../includes/admin-footer.php'; ?>
      <script src="<?php echo SITE_URL; ?>assets/js/admin.js"></script>
  </body>
  </html>