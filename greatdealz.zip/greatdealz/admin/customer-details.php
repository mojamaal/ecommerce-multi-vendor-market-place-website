<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isAdmin()) {
    header('Location: ../login.php');
    exit;
}

$customer_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$customer = $conn->query("SELECT * FROM users WHERE id = $customer_id AND role = 'customer'")->fetch_assoc();
$orders = $conn->query("SELECT * FROM orders WHERE user_id = $customer_id ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
$addresses = $conn->query("SELECT * FROM addresses WHERE user_id = $customer_id")->fetch_all(MYSQLI_ASSOC);

if (!$customer) {
    header('Location: customers.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Details - Greatdealz</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include '../includes/admin-header.php'; ?>
    
    <section class="admin-customer-details container">
        <h2>Customer Details</h2>
        <div class="customer-info">
            <p><strong>Name:</strong> <?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($customer['email']); ?></p>
            <p><strong>Joined:</strong> <?php echo date('F j, Y', strtotime($customer['created_at'])); ?></p>
        </div>
        <div class="customer-orders">
            <h3>Recent Orders</h3>
            <?php if (empty($orders)): ?>
                <p>No orders found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Total (LKR)</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?php echo $order['id']; ?></td>
                                <td><?php echo date('Y-m-d', strtotime($order['created_at'])); ?></td>
                                <td><?php echo CURRENCY . ' ' . number_format($order['total_amount'], 2); ?></td>
                                <td><?php echo ucfirst($order['status']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <div class="customer-addresses">
            <h3>Addresses</h3>
            <?php if (empty($addresses)): ?>
                <p>No addresses found.</p>
            <?php else: ?>
                <?php foreach ($addresses as $address): ?>
                    <div class="address-item">
                        <p><?php echo htmlspecialchars($address['address_line1'] . ', ' . $address['city'] . ', ' . $address['country']); ?></p>
                        <p>Type: <?php echo ucfirst($address['address_type']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <a href="customers.php" class="action-button">Back to Customers</a>
    </section>
    
    <?php include '../includes/admin-footer.php'; ?>
    <script src="../assets/js/admin.js"></script>
</body>
</html>