<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isAdmin()) {
    header('Location: ../login.php');
    exit;
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$order = $conn->query("SELECT o.*, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = $order_id")->fetch_assoc();
$items = $conn->query("SELECT oi.*, p.name, pi.image_path FROM order_items oi JOIN products p ON oi.product_id = p.id LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_main = 1 WHERE oi.order_id = $order_id")->fetch_all(MYSQLI_ASSOC);
$suppliers = $conn->query("SELECT id, name FROM suppliers")->fetch_all(MYSQLI_ASSOC);

if (!$order) {
    header('Location: orders.php');
    exit;
}

// Assign suppliers to order items
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_suppliers'])) {
    $supplier_assignments = [];
    if (isset($_POST['supplier']) && is_array($_POST['supplier'])) {
        foreach ($_POST['supplier'] as $product_id => $suppliers) {
            foreach ($suppliers as $item_id => $supp_id) {
                $qty = isset($_POST['quantity'][$product_id][$item_id]) ? (int)$_POST['quantity'][$product_id][$item_id] : 0;
                if ($supp_id && $qty > 0) {
                    $supplier_assignments[$product_id][] = ['supplier_id' => (int)$supp_id, 'quantity' => $qty];
                }
            }
        }
    }
    // Update order_items with supplier assignments
    foreach ($items as $item) {
        $product_id = $item['product_id'];
        if (isset($supplier_assignments[$product_id]) && !empty($supplier_assignments[$product_id])) {
            $new_supplier_id = $supplier_assignments[$product_id][0]['supplier_id'];
            // Validate supplier_id exists in suppliers table
            $stmt = $conn->prepare("SELECT id FROM suppliers WHERE id = ?");
            $stmt->bind_param("i", $new_supplier_id);
            $stmt->execute();
            $supplier_exists = $stmt->get_result()->fetch_assoc();
            
            if ($supplier_exists) {
                $stmt = $conn->prepare("UPDATE order_items SET supplier_id = ? WHERE order_id = ? AND product_id = ?");
                $stmt->bind_param("iii", $new_supplier_id, $order_id, $product_id);
                $stmt->execute();

                // Decrease stock in supplier_products
                $remaining_quantity = $item['quantity'];
                $stmt = $conn->prepare("SELECT stock_quantity FROM supplier_products WHERE supplier_id = ? AND product_id = ?");
                $stmt->bind_param("ii", $new_supplier_id, $product_id);
                $stmt->execute();
                $supplier_stock = $stmt->get_result()->fetch_assoc();
                if ($supplier_stock) {
                    $decrease_amount = min($remaining_quantity, $supplier_stock['stock_quantity']);
                    if ($decrease_amount > 0) {
                        $stmt = $conn->prepare("UPDATE supplier_products SET stock_quantity = stock_quantity - ? WHERE supplier_id = ? AND product_id = ?");
                        $stmt->bind_param("iii", $decrease_amount, $new_supplier_id, $product_id);
                        $stmt->execute();
                        $remaining_quantity -= $decrease_amount;
                    }
                    if ($remaining_quantity > 0) {
                        error_log("Not enough stock to fulfill order item for product ID {$product_id}. Remaining quantity: $remaining_quantity");
                    }
                }
            } else {
                error_log("Invalid supplier ID {$new_supplier_id} for product ID {$product_id} in order ID {$order_id}");
            }
        }
    }
    header('Location: order-details.php?id=' . $order_id);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details - Greatdealz</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include '../includes/admin-header.php'; ?>
    
    <section class="admin-order-details container">
        <h2>Order Details #<?php echo $order_id; ?></h2>
        <div class="order-info">
            <p><strong>Customer:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
            <p><strong>Total:</strong> <?php echo CURRENCY . ' ' . number_format($order['total_amount'], 2); ?></p>
            <p><strong>Status:</strong> <?php echo ucfirst($order['status']); ?></p>
            <p><strong>Payment Method:</strong> <?php echo ucfirst($order['payment_method']); ?></p>
            <p><strong>Payment Status:</strong> <?php echo ucfirst($order['payment_status']); ?></p>
            <p><strong>Shipping Address:</strong> <?php echo htmlspecialchars(json_decode($order['shipping_address'], true)['address_line1'] . ', ' . json_decode($order['shipping_address'], true)['city']); ?></p>
            <p><strong>Billing Address:</strong> <?php echo htmlspecialchars(json_decode($order['billing_address'], true)['address_line1'] . ', ' . json_decode($order['billing_address'], true)['city']); ?></p>
            <p><strong>Order Date:</strong> <?php echo date('F j, Y', strtotime($order['created_at'])); ?></p>
            <p><strong>Estimated Delivery:</strong> <?php echo date('F j, Y', strtotime($order['estimated_delivery'])); ?></p>
        </div>
        <div class="order-items">
            <h3>Order Items</h3>
            <?php if (empty($suppliers)): ?>
                <p>No suppliers available to assign. Please add suppliers first.</p>
            <?php else: ?>
                <form method="post">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Unit Price (LKR)</th>
                                <th>Total (LKR)</th>
                                <th>Assign Supplier</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td><?php echo CURRENCY . ' ' . number_format($item['unit_price'], 2); ?></td>
                                    <td><?php echo CURRENCY . ' ' . number_format($item['unit_price'] * $item['quantity'], 2); ?></td>
                                    <td>
                                        <select name="supplier[<?php echo $item['product_id']; ?>][<?php echo $item['id']; ?>]" required>
                                            <option value="">Select Supplier</option>
                                            <?php foreach ($suppliers as $supplier): ?>
                                                <option value="<?php echo $supplier['id']; ?>" <?php echo $item['supplier_id'] == $supplier['id'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($supplier['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <input type="number" name="quantity[<?php echo $item['product_id']; ?>][<?php echo $item['id']; ?>]" min="1" max="<?php echo $item['quantity']; ?>" value="<?php echo $item['quantity']; ?>" placeholder="Quantity" required>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
                    <button type="submit" name="assign_suppliers" class="action-button">Assign Suppliers</button>
                </form>
            <?php endif; ?>
        </div>
        <a href="orders.php" class="action-button">Back to Orders</a>
    </section>
    
    <?php include '../includes/admin-footer.php'; ?>
    <script src="../assets/js/admin.js"></script>
</body>
</html>