<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

// Initialize session and generate CSRF token
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isAdmin()) {
    header('Location: ../login.php');
    exit;
}

// Fetch all suppliers
$suppliers = getAllSuppliers() ?: [];

// Handle form submission for filters
$start_date = isset($_POST['start_date']) ? $_POST['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_POST['end_date']) ? $_POST['end_date'] : date('Y-m-d');
$supplier_id = isset($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : null;
$chart_type = isset($_POST['chart_type']) ? $_POST['chart_type'] : 'line';
$chart_metric = isset($_POST['chart_metric']) ? $_POST['chart_metric'] : 'sales';

// Reset filters if requested
if (isset($_POST['reset_filters'])) {
    $start_date = date('Y-m-d', strtotime('-30 days'));
    $end_date = date('Y-m-d');
    $supplier_id = null;
    $chart_type = 'line';
    $chart_metric = 'sales';
}

// Fetch admin-level sales data
$sales_data = getAdminSalesReport($start_date, $end_date, $supplier_id);
$top_products = getAdminTopSellingProducts($start_date, $end_date, 5);

// Generate CSV if requested
if (isset($_POST['download_csv'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="admin_sales_report_' . date('Ymd_His') . '.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Admin Report', '', '', 'Report Date: ' . date('Y-m-d H:i:s')]);
    fputcsv($output, ['Sales Data']);
    fputcsv($output, ['Date', 'Total Quantity', 'Total Sales (LKR)']);
    foreach ($sales_data as $row) {
        fputcsv($output, [$row['sale_date'], $row['total_quantity'], number_format($row['total_sales'], 2)]);
    }
    fputcsv($output, ['', '', '']);
    fputcsv($output, ['Top Selling Products']);
    fputcsv($output, ['Product Name', 'Total Quantity Sold', 'Total Sales (LKR)']);
    foreach ($top_products as $product) {
        fputcsv($output, [$product['name'], $product['total_quantity'], number_format($product['total_sales'], 2)]);
    }
    fclose($output);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Reports - Greatdealz</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* General container styling */
        .admin-reports { 
            max-width: 1200px; 
            margin: 40px auto; 
            padding: 30px; 
            background: #ffffff; 
            border-radius: 12px; 
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); 
        }

        /* Headings */
        .admin-reports h2 { 
            font-size: 2.25rem; 
            font-weight: 600; 
            color: #1f2937; 
            margin-bottom: 30px; 
            border-bottom: 2px solid #e5e7eb; 
            padding-bottom: 10px; 
        }

        .admin-reports h3 { 
            font-size: 1.5rem; 
            font-weight: 500; 
            color: #374151; 
            margin: 40px 0 20px; 
        }

        /* Filter section */
        .filter-section { 
            margin-bottom: 40px; 
            padding: 20px; 
            background: #f9fafb; 
            border-radius: 8px; 
        }

        .filter-form { 
            display: flex; 
            gap: 20px; 
            flex-wrap: wrap; 
            align-items: flex-end; 
        }

        .filter-form div { 
            display: flex; 
            flex-direction: column; 
            min-width: 180px; 
        }

        .filter-form label { 
            font-size: 0.95rem; 
            font-weight: 500; 
            color: #4b5563; 
            margin-bottom: 8px; 
        }

        .filter-form input, 
        .filter-form select { 
            padding: 10px; 
            border: 1px solid #d1d5db; 
            border-radius: 6px; 
            font-size: 0.95rem; 
            background: #fff; 
            transition: border-color 0.2s ease; 
        }

        .filter-form input:focus, 
        .filter-form select:focus { 
            outline: none; 
            border-color: #ff6f61; 
            box-shadow: 0 0 0 3px rgba(255, 111, 97, 0.1); 
        }

        .filter-form button { 
            padding: 10px 20px; 
            background: #ff6f61; 
            color: #fff; 
            border: none; 
            border-radius: 6px; 
            cursor: pointer; 
            font-size: 0.95rem; 
            font-weight: 500; 
            transition: background-color 0.3s ease; 
        }

        .filter-form button:hover { 
            background: #e65b50; 
        }

        .filter-form button[name="reset_filters"] { 
            background: #6b7280; 
        }

        .filter-form button[name="reset_filters"]:hover { 
            background: #4b5563; 
        }

        /* Chart containers */
        .chart-container { 
            position: relative; 
            height: 400px; 
            width: 100%; 
            margin-bottom: 40px; 
            background: #f9fafb; 
            padding: 20px; 
            border-radius: 8px; 
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05); 
        }

        /* Tables */
        .report-table { 
            width: 100%; 
            border-collapse: separate; 
            border-spacing: 0; 
            background: #fff; 
            border-radius: 8px; 
            overflow: hidden; 
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05); 
            margin-bottom: 40px; 
        }

        .report-table th { 
            background: #ff6f61; 
            color: #fff; 
            padding: 16px 20px; 
            font-size: 1rem; 
            font-weight: 600; 
            text-align: left; 
        }

        .report-table td { 
            padding: 16px 20px; 
            color: #4b5563; 
            font-size: 0.95rem; 
            border-bottom: 1px solid #e5e7eb; 
            vertical-align: middle; 
        }

        .report-table tr:last-child td { 
            border-bottom: none; 
        }

        .report-table tr:hover { 
            background: #f9fafb; 
        }

        /* Download section */
        .download-section { 
            margin-top: 30px; 
            text-align: right; 
        }

        .download-section button { 
            padding: 10px 20px; 
            background: #ff6f61; 
            color: #fff; 
            border: none; 
            border-radius: 6px; 
            cursor: pointer; 
            font-size: 0.95rem; 
            font-weight: 500; 
            transition: background-color 0.3s ease; 
        }

        .download-section button:hover { 
            background: #e65b50; 
        }

        /* Alerts */
        .alert { 
            padding: 15px 20px; 
            margin-bottom: 30px; 
            border-radius: 6px; 
            font-size: 0.95rem; 
        }

        .alert-success { 
            background-color: #d4edda; 
            border: 1px solid #c3e6cb; 
            color: #155724; 
        }

        .alert-error { 
            background-color: #f8d7da; 
            border: 1px solid #f5c6cb; 
            color: #721c24; 
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-header.php'; ?>

    <section class="admin-reports container">
        <h2>Admin Reports - Greatdealz</h2>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <!-- Filter Section -->
        <div class="filter-section">
            <form method="post" class="filter-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div>
                    <label for="start_date">Start Date</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo $start_date; ?>" required>
                </div>
                <div>
                    <label for="end_date">End Date</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo $end_date; ?>" required>
                </div>
                <div>
                    <label for="supplier_id">Supplier</label>
                    <select id="supplier_id" name="supplier_id">
                        <option value="">All Suppliers</option>
                        <?php foreach ($suppliers as $supplier): ?>
                            <option value="<?php echo $supplier['id']; ?>" <?php echo $supplier_id == $supplier['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($supplier['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label for="chart_type">Chart Type</label>
                    <select id="chart_type" name="chart_type">
                        <option value="line" <?php echo $chart_type == 'line' ? 'selected' : ''; ?>>Line</option>
                        <option value="bar" <?php echo $chart_type == 'bar' ? 'selected' : ''; ?>>Bar</option>
                        <option value="pie" <?php echo $chart_type == 'pie' ? 'selected' : ''; ?>>Pie</option>
                    </select>
                </div>
                <div>
                    <label for="chart_metric">Chart Metric</label>
                    <select id="chart_metric" name="chart_metric">
                        <option value="sales" <?php echo $chart_metric == 'sales' ? 'selected' : ''; ?>>Sales Amount</option>
                        <option value="quantity" <?php echo $chart_metric == 'quantity' ? 'selected' : ''; ?>>Quantity</option>
                    </select>
                </div>
                <button type="submit">Apply Filters</button>
                <button type="submit" name="reset_filters">Reset Filters</button>
            </form>
        </div>

        <!-- Sales Data Chart -->
        <h3>Sales Data Chart</h3>
        <div class="chart-container">
            <canvas id="salesChart"></canvas>
        </div>

        <!-- Sales Data Table -->
        <?php if (!empty($sales_data)): ?>
            <h3>Sales Data Table</h3>
            <table class="report-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Total Quantity</th>
                        <th>Total Sales (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sales_data as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['sale_date']); ?></td>
                            <td><?php echo (int)$row['total_quantity']; ?></td>
                            <td><?php echo number_format($row['total_sales'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No sales data available for the selected filters.</p>
        <?php endif; ?>

        <!-- Top Selling Products Chart -->
        <?php if (!empty($top_products)): ?>
            <h3>Top Selling Products Chart</h3>
            <div class="chart-container">
                <canvas id="topProductsChart"></canvas>
            </div>
        <?php endif; ?>

        <!-- Top Selling Products Table -->
        <?php if (!empty($top_products)): ?>
            <h3>Top Selling Products Table</h3>
            <table class="report-table">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Total Quantity Sold</th>
                        <th>Total Sales (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($top_products as $product): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                            <td><?php echo (int)$product['total_quantity']; ?></td>
                            <td><?php echo number_format($product['total_sales'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No top selling products available for the selected filters.</p>
        <?php endif; ?>

        <!-- Download Section -->
        <div class="download-section">
            <form method="post" style="display:inline;">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <button type="submit" name="download_csv">Download as CSV</button>
            </form>
        </div>
    </section>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Sales Data Chart
            const salesCtx = document.getElementById('salesChart').getContext('2d');
            const salesData = <?php echo json_encode($sales_data); ?>;
            
            // Group sales data by year and month
            const monthlyData = {};
            salesData.forEach(row => {
                const date = new Date(row.sale_date);
                const year = date.getFullYear();
                const month = date.toLocaleString('default', { month: 'long' });
                const key = `${year} - ${month}`;
                if (!monthlyData[key]) monthlyData[key] = { total_sales: 0, total_quantity: 0 };
                monthlyData[key].total_sales += row.total_sales;
                monthlyData[key].total_quantity += row.total_quantity;
            });

            const salesLabels = Object.keys(monthlyData);
            let salesPrimaryData = <?php echo $chart_metric == 'sales' ? 'Object.values(monthlyData).map(d => d.total_sales)' : 'Object.values(monthlyData).map(d => d.total_quantity)'; ?>;
            const salesSecondaryData = <?php echo $chart_metric == 'sales' ? 'Object.values(monthlyData).map(d => d.total_quantity)' : 'Object.values(monthlyData).map(d => d.total_sales)'; ?>;

            const salesChart = new Chart(salesCtx, {
                type: '<?php echo $chart_type; ?>',
                data: {
                    labels: salesLabels,
                    datasets: [{
                        label: '<?php echo $chart_metric == 'sales' ? 'Total Sales (LKR)' : 'Total Quantity'; ?>',
                        data: salesPrimaryData,
                        borderColor: '#FF6F61',
                        backgroundColor: 'rgba(255, 111, 97, 0.2)',
                        fill: <?php echo $chart_type === 'line' ? 'true' : 'false'; ?>,
                        tension: 0.1
                    }, {
                        label: '<?php echo $chart_metric == 'sales' ? 'Total Quantity' : 'Total Sales (LKR)'; ?>',
                        data: salesSecondaryData,
                        borderColor: '#6B7280',
                        backgroundColor: 'rgba(107, 114, 128, 0.2)',
                        fill: <?php echo $chart_type === 'line' ? 'true' : 'false'; ?>,
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'top' },
                        tooltip: { mode: 'index', intersect: false }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: { display: true, text: 'Value' }
                        },
                        x: {
                            title: { display: true, text: 'Month-Year' }
                        }
                    }
                }
            });

            // Top Selling Products Chart
            <?php if (!empty($top_products)): ?>
                const topProductsCtx = document.getElementById('topProductsChart').getContext('2d');
                const topProductsData = <?php echo json_encode($top_products); ?>;
                const topProductLabels = topProductsData.map(product => product.name);
                const topProductQuantities = topProductsData.map(product => product.total_quantity);
                const topProductSales = topProductsData.map(product => product.total_sales);

                new Chart(topProductsCtx, {
                    type: '<?php echo $chart_type; ?>',
                    data: {
                        labels: topProductLabels,
                        datasets: [{
                            label: 'Total Quantity Sold',
                            data: topProductQuantities,
                            borderColor: '#FF6F61',
                            backgroundColor: 'rgba(255, 111, 97, 0.2)',
                            fill: <?php echo $chart_type === 'line' ? 'true' : 'false'; ?>,
                            tension: 0.1
                        }, {
                            label: 'Total Sales (LKR)',
                            data: topProductSales,
                            borderColor: '#6B7280',
                            backgroundColor: 'rgba(107, 114, 128, 0.2)',
                            fill: <?php echo $chart_type === 'line' ? 'true' : 'false'; ?>,
                            tension: 0.1
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: { position: 'top' },
                            tooltip: { mode: 'index', intersect: false }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: { display: true, text: 'Value' }
                            },
                            x: {
                                title: { display: true, text: 'Product' }
                            }
                        }
                    }
                });
            <?php endif; ?>

            // Toggle chart metric for Sales Chart
            document.getElementById('chart_metric').addEventListener('change', function() {
                const metric = this.value;
                salesChart.data.datasets[0].label = metric === 'sales' ? 'Total Sales (LKR)' : 'Total Quantity';
                salesChart.data.datasets[0].data = metric === 'sales' ? Object.values(monthlyData).map(d => d.total_sales) : Object.values(monthlyData).map(d => d.total_quantity);
                salesChart.data.datasets[1].label = metric === 'sales' ? 'Total Quantity' : 'Total Sales (LKR)';
                salesChart.data.datasets[1].data = metric === 'sales' ? Object.values(monthlyData).map(d => d.total_quantity) : Object.values(monthlyData).map(d => d.total_sales);
                salesChart.update();
            });
        });
    </script>
</body>
</html>