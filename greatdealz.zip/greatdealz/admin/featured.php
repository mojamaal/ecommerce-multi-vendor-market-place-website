<?php
  require_once __DIR__ . '/../includes/config.php';
  require_once __DIR__ . '/../includes/functions.php';

  if (!isAdmin()) {
      header('Location: ../login.php');
      exit;
  }

  $featured = $conn->query("SELECT fp.*, p.name FROM featured_products fp JOIN products p ON fp.product_id = p.id ORDER BY fp.display_order")->fetch_all(MYSQLI_ASSOC);
  $products = $conn->query("SELECT id, name FROM products WHERE status = 'active'")->fetch_all(MYSQLI_ASSOC);

  if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_featured'])) {
      $product_id = (int)$_POST['product_id'];
      $display_order = $conn->query("SELECT MAX(display_order) FROM featured_products")->fetch_row()[0] + 1;
      $stmt = $conn->prepare("INSERT INTO featured_products (product_id, display_order) VALUES (?, ?)");
      $stmt->bind_param("ii", $product_id, $display_order);
      $stmt->execute();
      header('Location: featured.php');
      exit;
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['remove_featured'])) {
      $product_id = (int)$_POST['product_id'];
      $stmt = $conn->prepare("DELETE FROM featured_products WHERE product_id = ?");
      $stmt->bind_param("i", $product_id);
      $stmt->execute();
      header('Location: featured.php');
      exit;
  }
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Manage Featured Products - Greatdealz</title>
      <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
      <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/fonts/fontawesome/css/all.min.css">
  </head>
  <body>
      <?php include __DIR__ . '/../includes/admin-header.php'; ?>
      
      <section class="admin-featured container">
          <h2>Manage Featured Products</h2>
          <form method="post" class="add-featured-form">
              <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
              <div class="form-group">
                  <label for="product_id">Select Product</label>
                  <select id="product_id" name="product_id" required>
                      <option value="">Select Product</option>
                      <?php foreach ($products as $product): ?>
                          <option value="<?php echo $product['id']; ?>"><?php echo htmlspecialchars($product['name']); ?></option>
                      <?php endforeach; ?>
                  </select>
              </div>
              <div class="form-group">
                  <button type="submit" name="add_featured" class="action-button">Add to Featured</button>
              </div>
          </form>
          <div class="featured-list">
              <h3>Featured Products</h3>
              <table>
                  <thead>
                      <tr>
                          <th>Order</th>
                          <th>Product</th>
                          <th>Actions</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($featured as $item): ?>
                          <tr>
                              <td><?php echo $item['display_order']; ?></td>
                              <td><?php echo htmlspecialchars($item['name']); ?></td>
                              <td>
                                  <form method="post" style="display:inline;">
                                      <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                      <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
                                      <button type="submit" name="remove_featured" class="action-button" onclick="return confirm('Are you sure?');">Remove</button>
                                  </form>
                              </td>
                          </tr>
                      <?php endforeach; ?>
                  </tbody>
              </table>
          </div>
      </section>
      
      <?php include __DIR__ . '/../includes/admin-footer.php'; ?>
      <script src="<?php echo SITE_URL; ?>assets/js/admin.js"></script>
  </body>
  </html>