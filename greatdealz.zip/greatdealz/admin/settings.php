<?php
  require_once __DIR__ . '/../includes/config.php';
  require_once __DIR__ . '/../includes/functions.php';

  if (!isAdmin()) {
      header('Location: ../login.php');
      exit;
  }

  $settings = $conn->query("SELECT * FROM settings WHERE id = 1")->fetch_assoc();

  if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_settings'])) {
      $store_name = mysqli_real_escape_string($conn, $_POST['store_name']);
      $store_email = mysqli_real_escape_string($conn, $_POST['store_email']);
      $store_phone = mysqli_real_escape_string($conn, $_POST['store_phone']);
      $store_address = mysqli_real_escape_string($conn, $_POST['store_address']);
      
      $stmt = $conn->prepare("INSERT INTO settings (id, store_name, store_email, store_phone, store_address) VALUES (1, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE store_name = ?, store_email = ?, store_phone = ?, store_address = ?");
      $stmt->bind_param("ssssssss", $store_name, $store_email, $store_phone, $store_address, $store_name, $store_email, $store_phone, $store_address);
      $stmt->execute();
      header('Location: settings.php');
      exit;
  }
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Settings - Greatdealz</title>
      <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
      <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/fonts/fontawesome/css/all.min.css">
  </head>
  <body>
      <?php include __DIR__ . '/../includes/admin-header.php'; ?>
      
      <section class="admin-settings container">
          <h2>Store Settings</h2>
          <form method="post" class="settings-form">
              <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
              <div class="form-group">
                  <label for="store_name">Store Name</label>
                  <input type="text" id="store_name" name="store_name" value="<?php echo htmlspecialchars($settings['store_name'] ?? 'Greatdealz'); ?>" placeholder="Enter store name" required>
              </div>
              <div class="form-group">
                  <label for="store_email">Store Email</label>
                  <input type="email" id="store_email" name="store_email" value="<?php echo htmlspecialchars($settings['store_email'] ?? ''); ?>" placeholder="Enter store email" required>
              </div>
              <div class="form-group">
                  <label for="store_phone">Store Phone</label>
                  <input type="text" id="store_phone" name="store_phone" value="<?php echo htmlspecialchars($settings['store_phone'] ?? ''); ?>" placeholder="Enter store phone">
              </div>
              <div class="form-group">
                  <label for="store_address">Store Address</label>
                  <textarea id="store_address" name="store_address" placeholder="Enter store address"><?php echo htmlspecialchars($settings['store_address'] ?? ''); ?></textarea>
              </div>
              <div class="form-group">
                  <button type="submit" name="update_settings" class="action-button">Update Settings</button>
              </div>
          </form>
      </section>
      
      <?php include __DIR__ . '/../includes/admin-footer.php'; ?>
      <script src="<?php echo SITE_URL; ?>assets/js/admin.js"></script>
  </body>
  </html>