<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isAdmin()) {
    header('Location: ../login.php');
    exit;
}

$orders = $conn->query("SELECT o.*, u.email FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC")->fetch_all(MYSQLI_ASSOC);

// Update order status
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $order_id);
    $stmt->execute();
    
    header('Location: orders.php');
    exit;
}

// Update payment status
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_payment_status'])) {
    $order_id = (int)$_POST['order_id'];
    $payment_status = $_POST['payment_status'];
    $stmt = $conn->prepare("UPDATE orders SET payment_status = ? WHERE id = ?");
    $stmt->bind_param("si", $payment_status, $order_id);
    $stmt->execute();
    
    header('Location: orders.php');
    exit;
}

// Assign suppliers to order items
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_suppliers'])) {
    $order_id = (int)$_POST['order_id'];
    $supplier_assignments = [];
    if (isset($_POST['supplier']) && is_array($_POST['supplier'])) {
        foreach ($_POST['supplier'] as $product_id => $suppliers) {
            foreach ($suppliers as $supp_id => $qty) {
                $supplier_assignments[$product_id][] = ['supplier_id' => $supp_id, 'quantity' => (int)$qty];
            }
        }
    }
    // Simulate order creation with supplier assignments (for testing, normally done at checkout)
    createOrder(1, '{}', '{}', 'cash', $supplier_assignments); // Placeholder user_id and addresses
    header('Location: orders.php');
    exit;
}

$suppliers = $conn->query("SELECT id, name FROM suppliers")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - Greatdealz</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-header.php'; ?>
    
    <section class="admin-orders container">
        <h2>Manage Orders</h2>
        <div class="order-list">
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Total (LKR)</th>
                        <th>Status</th>
                        <th>Payment Status</th>
                        <th>Payment Method</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?php echo $order['id']; ?></td>
                            <td><?php echo htmlspecialchars($order['email']); ?></td>
                            <td><?php echo CURRENCY . ' ' . number_format($order['total_amount'], 2); ?></td>
                            <td>
                                <form method="post">
                                    <div class="form-group">
                                        <label for="status_<?php echo $order['id']; ?>" class="sr-only">Status</label>
                                        <select id="status_<?php echo $order['id']; ?>" name="status" onchange="this.form.submit()">
                                            <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="processing" <?php echo $order['status'] == 'processing' ? 'selected' : ''; ?>>Processing</option>
                                            <option value="shipped" <?php echo $order['status'] == 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                                            <option value="delivered" <?php echo $order['status'] == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                            <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                        </select>
                                    </div>
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
                                    <input type="hidden" name="update_status" value="1">
                                </form>
                            </td>
                            <td>
                                <form method="post">
                                    <div class="form-group">
                                        <label for="payment_status_<?php echo $order['id']; ?>" class="sr-only">Payment Status</label>
                                        <select id="payment_status_<?php echo $order['id']; ?>" name="payment_status" onchange="this.form.submit()">
                                            <option value="pending" <?php echo $order['payment_status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="completed" <?php echo $order['payment_status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                            <option value="failed" <?php echo $order['payment_status'] == 'failed' ? 'selected' : ''; ?>>Failed</option>
                                        </select>
                                    </div>
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
                                    <input type="hidden" name="update_payment_status" value="1">
                                </form>
                            </td>
                            <td><?php echo ucfirst($order['payment_method']); ?></td>
                            <td>
                                <a href="order-details.php?id=<?php echo $order['id']; ?>" class="action-button">Assign Suppliers</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
    
    <?php include __DIR__ . '/../includes/admin-footer.php'; ?>
    <script src="<?php echo SITE_URL; ?>assets/js/admin.js"></script>
</body>
</html>