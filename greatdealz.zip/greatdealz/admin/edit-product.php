<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isAdmin()) {
    header('Location: ../login.php');
    exit;
}

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$product = $conn->query("SELECT * FROM products WHERE id = $product_id")->fetch_assoc();
$categories = $conn->query("SELECT * FROM categories")->fetch_all(MYSQLI_ASSOC);
$suppliers = $conn->query("SELECT * FROM suppliers")->fetch_all(MYSQLI_ASSOC);
$current_suppliers = $conn->query("SELECT * FROM supplier_products WHERE product_id = $product_id")->fetch_all(MYSQLI_ASSOC);
$current_supplier_data = [];
foreach ($current_suppliers as $cs) {
    $current_supplier_data[$cs['supplier_id']] = $cs;
}

if (!$product) {
    header('Location: products.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_product'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $specifications = mysqli_real_escape_string($conn, $_POST['specifications']);
    $price = (float)$_POST['price'];
    $stock_quantity = (int)$_POST['stock_quantity'];
    $category_id = (int)$_POST['category_id'];
    $brand = mysqli_real_escape_string($conn, $_POST['brand']); // New brand field
    $status = $_POST['status'];
    $main_image = $product['main_image']; // Handle file upload in production

    $stmt = $conn->prepare("UPDATE products SET name = ?, description = ?, specifications = ?, price = ?, stock_quantity = ?, category_id = ?, brand = ?, main_image = ?, status = ? WHERE id = ?");
    $stmt->bind_param("sssdiisssi", $name, $description, $specifications, $price, $stock_quantity, $category_id, $brand, $main_image, $status, $product_id);
    if ($stmt->execute()) {
        // Update suppliers
        $conn->query("DELETE FROM supplier_products WHERE product_id = $product_id");
        if (isset($_POST['suppliers']) && is_array($_POST['suppliers'])) {
            foreach ($_POST['suppliers'] as $supplier_id => $data) {
                if (isset($data['selected']) && $data['selected'] == '1') {
                    $cost_price = (float)$data['cost_price'];
                    $supplier_quantity = (int)$data['quantity'];
                    $stmt = $conn->prepare("INSERT INTO supplier_products (supplier_id, product_id, cost_price, stock_quantity) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("iidi", $supplier_id, $product_id, $cost_price, $supplier_quantity);
                    $stmt->execute();
                }
            }
        }
        header('Location: products.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Greatdealz</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-header.php'; ?>
    
    <section class="admin-edit-product container">
        <h2>Edit Product</h2>
        <form method="post" class="edit-product-form">
            <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
            <input type="text" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" placeholder="Product Name" required>
            <textarea name="description" placeholder="Description" required><?php echo htmlspecialchars($product['description']); ?></textarea>
            <textarea name="specifications" placeholder="Specifications"><?php echo htmlspecialchars($product['specifications']); ?></textarea>
            <input type="number" name="price" value="<?php echo $product['price']; ?>" placeholder="Price (LKR)" step="0.01" required>
            <input type="number" name="stock_quantity" value="<?php echo $product['stock_quantity']; ?>" placeholder="Stock Quantity" required>
            <select name="category_id" required>
                <option value="">Select Category</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['id']; ?>" <?php echo $category['id'] == $product['category_id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($category['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="brand" value="<?php echo htmlspecialchars($product['brand']); ?>" placeholder="Brand" required>
            <select name="status" required>
                <option value="active" <?php echo $product['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                <option value="inactive" <?php echo $product['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
            </select>
            <h3>Assign Suppliers</h3>
            <?php foreach ($suppliers as $supplier): ?>
                <div class="supplier-row">
                    <label>
                        <input type="checkbox" name="suppliers[<?php echo $supplier['id']; ?>][selected]" value="1" <?php echo isset($current_supplier_data[$supplier['id']]) ? 'checked' : ''; ?>>
                        <?php echo htmlspecialchars($supplier['name']); ?>
                    </label>
                    <input type="number" name="suppliers[<?php echo $supplier['id']; ?>][cost_price]" placeholder="Cost Price (LKR)" step="0.01" value="<?php echo isset($current_supplier_data[$supplier['id']]) ? $current_supplier_data[$supplier['id']]['cost_price'] : ''; ?>">
                    <input type="number" name="suppliers[<?php echo $supplier['id']; ?>][quantity]" placeholder="Quantity" value="<?php echo isset($current_supplier_data[$supplier['id']]) ? $current_supplier_data[$supplier['id']]['stock_quantity'] : ''; ?>">
                </div>
            <?php endforeach; ?>
            <button type="submit" name="update_product" class="action-button">Update Product</button>
        </form>
    </section>
    
    <?php include __DIR__ . '/../includes/admin-footer.php'; ?>
    <script src="<?php echo SITE_URL; ?>assets/js/admin.js"></script>
</body>
</html>