<?php
  require_once __DIR__ . '/../includes/config.php';
  require_once __DIR__ . '/../includes/functions.php';

  if (!isAdmin()) {
      header('Location: ../login.php');
      exit;
  }

  $category_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
  $category = $conn->query("SELECT * FROM categories WHERE id = $category_id")->fetch_assoc();
  $categories = $conn->query("SELECT * FROM categories WHERE id != $category_id")->fetch_all(MYSQLI_ASSOC);

  if (!$category) {
      header('Location: categories.php');
      exit;
  }

  if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_category'])) {
      $name = mysqli_real_escape_string($conn, $_POST['name']);
      $parent_id = $_POST['parent_id'] ? (int)$_POST['parent_id'] : null;
      $stmt = $conn->prepare("UPDATE categories SET name = ?, parent_id = ? WHERE id = ?");
      $stmt->bind_param("sii", $name, $parent_id, $category_id);
      $stmt->execute();
      header('Location: categories.php');
      exit;
  }
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Edit Category - Greatdealz</title>
      <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/css/admin.css">
      <link rel="stylesheet" href="<?php echo SITE_URL; ?>assets/fonts/fontawesome/css/all.min.css">
  </head>
  <body>
      <?php include __DIR__ . '/../includes/admin-header.php'; ?>
      
      <section class="admin-edit-category container">
          <h2>Edit Category</h2>
          <form method="post" class="edit-category-form">
              <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
              <div class="form-group">
                  <label for="name">Category Name</label>
                  <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($category['name']); ?>" placeholder="Enter category name" required>
              </div>
              <div class="form-group">
                  <label for="parent_id">Parent Category</label>
                  <select id="parent_id" name="parent_id">
                      <option value="">No Parent</option>
                      <?php foreach ($categories as $cat): ?>
                          <option value="<?php echo $cat['id']; ?>" <?php echo $cat['id'] == $category['parent_id'] ? 'selected' : ''; ?>>
                              <?php echo htmlspecialchars($cat['name']); ?>
                          </option>
                      <?php endforeach; ?>
                  </select>
              </div>
              <div class="form-group">
                  <button type="submit" name="update_category" class="action-button">Update Category</button>
              </div>
          </form>
      </section>
      
      <?php include __DIR__ . '/../includes/admin-footer.php'; ?>
      <script src="<?php echo SITE_URL; ?>assets/js/admin.js"></script>
  </body>
  </html>