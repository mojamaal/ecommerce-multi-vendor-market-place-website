<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$address_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$address = $conn->query("SELECT * FROM addresses WHERE id = $address_id AND user_id = {$_SESSION['user_id']}")->fetch_assoc();

if (!$address) {
    header('Location: account.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $address_type = $_POST['address_type'];
    $address_line1 = mysqli_real_escape_string($conn, $_POST['address_line1']);
    $address_line2 = mysqli_real_escape_string($conn, $_POST['address_line2']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $postal_code = mysqli_real_escape_string($conn, $_POST['postal_code']);
    $country = mysqli_real_escape_string($conn, $_POST['country']);
    
    $stmt = $conn->prepare("UPDATE addresses SET address_type = ?, address_line1 = ?, address_line2 = ?, city = ?, postal_code = ?, country = ? WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ssssssii", $address_type, $address_line1, $address_line2, $city, $postal_code, $country, $address_id, $_SESSION['user_id']);
    if ($stmt->execute()) {
        header('Location: account.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Address - Greatdealz</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="edit-address container">
        <h2>Edit Address</h2>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?php echo bin2hex(random_bytes(32)); ?>">
            <select name="address_type" required>
                <option value="shipping" <?php echo $address['address_type'] == 'shipping' ? 'selected' : ''; ?>>Shipping</option>
                <option value="billing" <?php echo $address['address_type'] == 'billing' ? 'selected' : ''; ?>>Billing</option>
            </select>
            <input type="text" name="address_line1" value="<?php echo htmlspecialchars($address['address_line1']); ?>" placeholder="Address Line 1" required>
            <input type="text" name="address_line2" value="<?php echo htmlspecialchars($address['address_line2']); ?>" placeholder="Address Line 2">
            <input type="text" name="city" value="<?php echo htmlspecialchars($address['city']); ?>" placeholder="City" required>
            <input type="text" name="postal_code" value="<?php echo htmlspecialchars($address['postal_code']); ?>" placeholder="Postal Code" required>
            <input type="text" name="country" value="<?php echo htmlspecialchars($address['country']); ?>" placeholder="Country" required>
            <button type="submit" class="action-button">Update Address</button>
        </form>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>