<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

// Initialize session and generate CSRF token
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isSupplier()) {
    header('Location: ../login.php');
    exit;
}

$supplier = getSupplierById($_SESSION['supplier_id']);
if (!$supplier) {
    die("Supplier not found.");
}

// Fetch bank details
$stmt = $conn->prepare("SELECT bank_name, account_number, account_holder, ifsc_code FROM supplier_bank_details WHERE supplier_id = ?");
$stmt->bind_param("i", $supplier['id']);
$stmt->execute();
$bank_details = $stmt->get_result()->fetch_assoc();
if (!$bank_details) {
    $bank_details = ['bank_name' => '', 'account_number' => '', 'account_holder' => '', 'ifsc_code' => ''];
}

// Function to validate CSRF token
function validateCSRF($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!validateCSRF($_POST['csrf_token'] ?? '')) {
        die("CSRF token validation failed.");
    }

    // Update supplier profile
    if (isset($_POST['update_profile'])) {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $contact_email = mysqli_real_escape_string($conn, $_POST['contact_email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);

        if (updateSupplierProfile($supplier['id'], $name, $contact_email, $phone, $address)) {
            $_SESSION['success_message'] = "Profile updated successfully.";
            $supplier = getSupplierById($supplier['id']); // Refresh supplier data
        } else {
            $_SESSION['error_message'] = "Failed to update profile.";
        }
        header('Location: supplier-profile.php');
        exit;
    }

    // Update bank details
    if (isset($_POST['update_bank_details'])) {
        $bank_name = mysqli_real_escape_string($conn, $_POST['bank_name']);
        $account_number = mysqli_real_escape_string($conn, $_POST['account_number']);
        $account_holder = mysqli_real_escape_string($conn, $_POST['account_holder']);
        $ifsc_code = mysqli_real_escape_string($conn, $_POST['ifsc_code']);

        if (updateSupplierBankDetails($supplier['id'], $bank_name, $account_number, $account_holder, $ifsc_code)) {
            $_SESSION['success_message'] = "Bank details updated successfully.";
            // Refresh bank details
            $stmt = $conn->prepare("SELECT bank_name, account_number, account_holder, ifsc_code FROM supplier_bank_details WHERE supplier_id = ?");
            $stmt->bind_param("i", $supplier['id']);
            $stmt->execute();
            $bank_details = $stmt->get_result()->fetch_assoc();
        } else {
            $_SESSION['error_message'] = "Failed to update bank details.";
        }
        header('Location: supplier-profile.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Profile - Greatdealz</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome/css/all.min.css">
    <style>
        .supplier-profile { max-width: 800px; margin: 20px auto; padding: 20px; background: #fff; border-radius: 10px; box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1); }
        .supplier-profile h2 { font-size: 2rem; color: #6B7280; margin-bottom: 20px; }
        .supplier-profile h3 { font-size: 1.5rem; color: #6B7280; margin-bottom: 15px; }
        .supplier-profile .section { margin-bottom: 30px; }
        .supplier-profile .form-group { margin-bottom: 15px; }
        .supplier-profile .form-group label { display: block; margin-bottom: 5px; font-size: 1rem; color: #6B7280; }
        .supplier-profile .form-group input, .supplier-profile .form-group textarea { width: 100%; padding: 10px; border: 1px solid #6B7280; border-radius: 5px; font-size: 1rem; transition: border-color 0.3s ease; }
        .supplier-profile .form-group input:focus, .supplier-profile .form-group textarea:focus { border-color: #FF6F61; outline: none; }
        .supplier-profile .form-group textarea { min-height: 80px; }
        .supplier-profile button { padding: 10px 20px; background: #FF6F61; color: #fff; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s ease; }
        .supplier-profile button:hover { background: #E65B50; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .alert-success { background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .alert-error { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
    </style>
</head>
<body>
     <?php include __DIR__ . '/header.php'; ?>

    
    <section class="supplier-profile container">
        <h2>Manage Profile - <?php echo htmlspecialchars($supplier['name']); ?></h2>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <!-- Update Profile Section -->
        <div class="section">
            <h3>Update Profile</h3>
            <form method="post" class="update-profile-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group">
                    <label for="name">Company Name</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($supplier['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="contact_email">Contact Email</label>
                    <input type="email" id="contact_email" name="contact_email" value="<?php echo htmlspecialchars($supplier['contact_email']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($supplier['phone']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address" name="address" required><?php echo htmlspecialchars($supplier['address']); ?></textarea>
                </div>
                <button type="submit" name="update_profile">Update Profile</button>
            </form>
        </div>

        <!-- Update Bank Details Section -->
        <div class="section">
            <h3>Update Bank Details</h3>
            <form method="post" class="update-bank-details-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group">
                    <label for="bank_name">Bank Name</label>
                    <input type="text" id="bank_name" name="bank_name" value="<?php echo htmlspecialchars($bank_details['bank_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="account_number">Account Number</label>
                    <input type="text" id="account_number" name="account_number" value="<?php echo htmlspecialchars($bank_details['account_number']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="account_holder">Account Holder</label>
                    <input type="text" id="account_holder" name="account_holder" value="<?php echo htmlspecialchars($bank_details['account_holder']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="ifsc_code">IFSC Code</label>
                    <input type="text" id="ifsc_code" name="ifsc_code" value="<?php echo htmlspecialchars($bank_details['ifsc_code']); ?>" required>
                </div>
                <button type="submit" name="update_bank_details">Update Bank Details</button>
            </form>
        </div>
    </section>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="../assets/js/main.js"></script>
</body>
</html>