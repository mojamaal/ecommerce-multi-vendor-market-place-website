<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isSupplier()) {
    header('Location: ../login.php');
    exit;
}

$supplier = getSupplierById($_SESSION['supplier_id']);
if (!$supplier) {
    die("Supplier not found.");
}

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($product_id <= 0) {
    header('Location: dashboard.php?error=Invalid product ID');
    exit;
}

// Fetch the product
$product = getProductById($product_id);
if (!$product) {
    header('Location: dashboard.php?error=Product not found');
    exit;
}

// Check if the product is associated with this supplier via supplier_products table
$supplier_product = $conn->prepare("SELECT cost_price, stock_quantity FROM supplier_products WHERE product_id = ? AND supplier_id = ?");
$supplier_product->bind_param("ii", $product_id, $supplier['id']);
$supplier_product->execute();
$supplier_product_result = $supplier_product->get_result()->fetch_assoc();

if (!$supplier_product_result) {
    header('Location: dashboard.php?error=Unauthorized access to this product');
    exit;
}

// Merge supplier-specific product details (cost_price, stock_quantity) into the product array
$product['cost_price'] = $supplier_product_result['cost_price'];
$product['stock_quantity'] = $supplier_product_result['stock_quantity'];

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("CSRF token validation failed.");
    }

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $cost_price = (float)$_POST['cost_price'];
    $stock_quantity = (int)$_POST['stock_quantity'];
    if (updateSupplierProduct($supplier['id'], $product_id, $cost_price, $stock_quantity, $name, $description)) {
        header('Location: dashboard.php?success=Product updated successfully');
        exit;
    } else {
        $error = "Update failed. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Greatdealz</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <section class="admin-edit-product container">
        <h2>Edit Product</h2>
        <?php if ($error): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <form method="post" class="edit-product-form">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="form-group">
                <label for="name">Product Name</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description"><?php echo htmlspecialchars($product['description']); ?></textarea>
            </div>
            <div class="form-group">
                <label for="cost_price">Cost Price (LKR)</label>
                <input type="number" id="cost_price" name="cost_price" value="<?php echo htmlspecialchars($product['cost_price']); ?>" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="stock_quantity">Stock Quantity</label>
                <input type="number" id="stock_quantity" name="stock_quantity" value="<?php echo htmlspecialchars($product['stock_quantity']); ?>" required>
            </div>
            <button type="submit" class="action-button">Update Product</button>
        </form>
    </section>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="../assets/js/main.js"></script>
</body>
</html>