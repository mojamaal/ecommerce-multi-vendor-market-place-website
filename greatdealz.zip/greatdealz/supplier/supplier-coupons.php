<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

// Initialize session and generate CSRF token
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isSupplier()) {
    header('Location: ../login.php');
    exit;
}

$supplier = getSupplierById($_SESSION['supplier_id']);
if (!$supplier) {
    die("Supplier not found.");
}

// Fetch existing coupons
$coupons = getCoupons($supplier['id']);

// Function to validate CSRF token
function validateCSRF($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Function to delete a coupon
function deleteCoupon($coupon_id, $supplier_id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM coupons WHERE id = ? AND supplier_id = ?");
    $stmt->bind_param("ii", $coupon_id, $supplier_id);
    return $stmt->execute();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!validateCSRF($_POST['csrf_token'] ?? '')) {
        die("CSRF token validation failed.");
    }

    // Create new coupon
    if (isset($_POST['create_coupon'])) {
        $code = mysqli_real_escape_string($conn, $_POST['code']);
        $discount = (float)$_POST['discount'];
        $valid_from = $_POST['valid_from'];
        $valid_to = $_POST['valid_to'];

        // Basic validation
        if (empty($code) || $discount <= 0 || empty($valid_from) || empty($valid_to)) {
            $_SESSION['error_message'] = "All fields are required, and discount must be greater than 0.";
        } elseif (strtotime($valid_from) > strtotime($valid_to)) {
            $_SESSION['error_message'] = "Valid From date must be earlier than Valid To date.";
        } else {
            if (createCoupon($supplier['id'], $code, $discount, $valid_from, $valid_to)) {
                $_SESSION['success_message'] = "Coupon created successfully.";
            } else {
                $_SESSION['error_message'] = "Failed to create coupon.";
            }
        }
        header('Location: supplier-coupons.php');
        exit;
    }

    // Delete coupon
    if (isset($_POST['delete_coupon'])) {
        $coupon_id = (int)$_POST['coupon_id'];
        if (deleteCoupon($coupon_id, $supplier['id'])) {
            $_SESSION['success_message'] = "Coupon deleted successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to delete coupon.";
        }
        header('Location: supplier-coupons.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Coupons - Greatdealz</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome/css/all.min.css">
    <style>
        .supplier-coupons { max-width: 1000px; margin: 20px auto; padding: 20px; background: #fff; border-radius: 10px; box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1); }
        .supplier-coupons h2 { font-size: 2rem; color: #6B7280; margin-bottom: 20px; }
        .supplier-coupons h3 { font-size: 1.5rem; color: #6B7280; margin-bottom: 15px; }
        .supplier-coupons .section { margin-bottom: 30px; }
        .supplier-coupons .form-group { margin-bottom: 15px; }
        .supplier-coupons .form-group label { display: block; margin-bottom: 5px; font-size: 1rem; color: #6B7280; }
        .supplier-coupons .form-group input { width: 100%; padding: 10px; border: 1px solid #6B7280; border-radius: 5px; font-size: 1rem; transition: border-color 0.3s ease; }
        .supplier-coupons .form-group input:focus { border-color: #FF6F61; outline: none; }
        .supplier-coupons .create-coupon-form { display: flex; gap: 15px; flex-wrap: wrap; align-items: flex-end; }
        .supplier-coupons .create-coupon-form button { padding: 10px 20px; background: #FF6F61; color: #fff; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s ease; }
        .supplier-coupons .create-coupon-form button:hover { background: #E65B50; }
        .supplier-coupons table { width: 100%; border-collapse: collapse; background: #fff; box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; overflow: hidden; }
        .supplier-coupons th { background: #FF6F61; color: #fff; padding: 15px; }
        .supplier-coupons td { padding: 15px; color: #6B7280; border-bottom: 1px solid #eee; }
        .supplier-coupons tr:hover { background: #f5f5f5; }
        .supplier-coupons .delete-coupon-button {
            background: #DC3545;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 5px 10px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }
        .supplier-coupons .delete-coupon-button:hover {
            background: #C82333;
            transform: scale(1.05);
        }
        .supplier-coupons .delete-coupon-button:active {
            transform: scale(0.95);
        }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .alert-success { background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .alert-error { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
    </style>
</head>
<body>
         <?php include __DIR__ . '/header.php'; ?>
    <section class="supplier-coupons container">
        <h2>Manage Coupons - <?php echo htmlspecialchars($supplier['name']); ?></h2>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <!-- Create Coupon Section -->
        <div class="section">
            <h3>Create New Coupon</h3>
            <form method="post" class="create-coupon-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group">
                    <label for="code">Coupon Code</label>
                    <input type="text" id="code" name="code" required>
                </div>
                <div class="form-group">
                    <label for="discount">Discount (%)</label>
                    <input type="number" id="discount" name="discount" step="0.01" min="0" max="100" required>
                </div>
                <div class="form-group">
                    <label for="valid_from">Valid From</label>
                    <input type="date" id="valid_from" name="valid_from" required>
                </div>
                <div class="form-group">
                    <label for="valid_to">Valid To</label>
                    <input type="date" id="valid_to" name="valid_to" required>
                </div>
                <button type="submit" name="create_coupon">Create Coupon</button>
            </form>
        </div>

        <!-- Existing Coupons Section -->
        <div class="section">
            <h3>Existing Coupons</h3>
            <?php if (empty($coupons)): ?>
                <p>No coupons found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Discount (%)</th>
                            <th>Valid From</th>
                            <th>Valid To</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($coupons as $coupon): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($coupon['code']); ?></td>
                                <td><?php echo number_format($coupon['discount'], 2); ?></td>
                                <td><?php echo htmlspecialchars($coupon['valid_from']); ?></td>
                                <td><?php echo htmlspecialchars($coupon['valid_to']); ?></td>
                                <td>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                        <input type="hidden" name="coupon_id" value="<?php echo $coupon['id']; ?>">
                                        <button type="submit" name="delete_coupon" class="delete-coupon-button" onclick="return confirm('Are you sure you want to delete this coupon?');" title="Delete Coupon" aria-label="Delete this coupon">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </section>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="../assets/js/main.js"></script>
</body>
</html>