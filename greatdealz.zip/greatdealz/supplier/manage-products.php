<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

// Initialize session and generate CSRF token
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isSupplier()) {
    header('Location: ../login.php');
    exit;
}

$supplier = getSupplierById($_SESSION['supplier_id']);
if (!$supplier) {
    die("Supplier not found.");
}

// Function to validate CSRF token
function validateCSRF($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Fetch existing products
$products = getSupplierProducts($supplier['id']) ?: [];

// Fetch categories for the add product form
$categories = $conn->query("SELECT id, name FROM categories")->fetch_all(MYSQLI_ASSOC);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!validateCSRF($_POST['csrf_token'] ?? '')) {
        die("CSRF token validation failed.");
    }

    // Add new product
    if (isset($_POST['add_product'])) {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $category_id = (int)$_POST['category_id'];
        $brand = mysqli_real_escape_string($conn, $_POST['brand']);
        $price = (float)$_POST['price'];
        $cost_price = (float)$_POST['cost_price'];
        $stock_quantity = (int)$_POST['stock_quantity'];

        if (addSupplierProduct($supplier['id'], $name, $description, $category_id, $brand, $price, $cost_price, $stock_quantity)) {
            $product_id = $conn->insert_id;
            if (isset($_FILES['main_image']) && $_FILES['main_image']['error'] === UPLOAD_ERR_OK) {
                updateMainImage($product_id, $_FILES['main_image']);
            }
            if (isset($_FILES['additional_images']) && !empty($_FILES['additional_images']['name'][0])) {
                updateAdditionalImages($product_id, $_FILES['additional_images']);
            }
            $_SESSION['success_message'] = "Product added successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to add product.";
        }
        header('Location: manage-products.php');
        exit;
    }

    // Update existing product
    if (isset($_POST['update_product'])) {
        $product_id = (int)$_POST['product_id'];
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $cost_price = (float)$_POST['cost_price'];
        $stock_quantity = (int)$_POST['stock_quantity'];

        if (updateSupplierProduct($supplier['id'], $product_id, $cost_price, $stock_quantity, $name, $description)) {
            if (isset($_FILES['main_image']) && $_FILES['main_image']['error'] === UPLOAD_ERR_OK) {
                updateMainImage($product_id, $_FILES['main_image']);
            } elseif (isset($_POST['remove_main_image']) && $_POST['remove_main_image'] === '1') {
                updateMainImage($product_id, null);
            }
            if (isset($_FILES['additional_images']) && !empty($_FILES['additional_images']['name'][0])) {
                updateAdditionalImages($product_id, $_FILES['additional_images']);
            }
            $_SESSION['success_message'] = "Product updated successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to update product.";
        }
        header('Location: manage-products.php');
        exit;
    }

    // Delete additional image
    if (isset($_POST['delete_image'])) {
        $image_id = (int)$_POST['image_id'];
        $product_id = (int)$_POST['product_id'];
        if (deleteAdditionalImage($image_id, $product_id)) {
            $_SESSION['success_message'] = "Image deleted successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to delete image.";
        }
        header('Location: manage-products.php');
        exit;
    }

    // Delete product
    if (isset($_POST['delete_product'])) {
        $product_id = (int)$_POST['product_id'];
        if (deleteSupplierProduct($supplier['id'], $product_id)) {
            $_SESSION['success_message'] = "Product deleted successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to delete product.";
        }
        header('Location: manage-products.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Greatdealz</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome/css/all.min.css">
    <style>
        .manage-products { max-width: 1200px; margin: 20px auto; padding: 20px; background: #fff; border-radius: 10px; box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1); }
        .manage-products h2 { font-size: 2rem; color: #6B7280; margin-bottom: 20px; }
        .manage-products h3 { font-size: 1.5rem; color: #6B7280; margin-bottom: 15px; }
        .manage-products .section { margin-bottom: 30px; }
        .manage-products table { width: 100%; border-collapse: collapse; background: #fff; box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; overflow: hidden; }
        .manage-products th { background: #FF6F61; color: #fff; padding: 15px; }
        .manage-products td { padding: 15px; color: #6B7280; border-bottom: 1px solid #eee; }
        .manage-products tr:hover { background: #f5f5f5; }
        .manage-products .form-group { margin-bottom: 15px; }
        .manage-products .form-group label { display: block; margin-bottom: 5px; font-size: 1rem; color: #6B7280; }
        .manage-products .form-group input, .manage-products .form-group select, .manage-products .form-group textarea { width: 100%; padding: 10px; border: 1px solid #6B7280; border-radius: 5px; font-size: 1rem; transition: border-color 0.3s ease; }
        .manage-products .form-group input[type="file"] { padding: 5px; }
        .manage-products .form-group input:focus, .manage-products .form-group select:focus, .manage-products .form-group textarea:focus { border-color: #FF6F61; outline: none; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .alert-success { background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .alert-error { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
        .inline-form { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        .inline-form input, .inline-form select { width: auto; min-width: 80px; }
        .inline-form textarea { width: 100%; min-height: 60px; }
        .inline-form button { white-space: nowrap; }
        .image-preview { max-width: 100px; max-height: 100px; margin: 5px 0; }
        .image-list { display: flex; gap: 10px; flex-wrap: wrap; }
        .image-list img { max-width: 100px; max-height: 100px; }
        .image-item { position: relative; display: inline-block; }
        .image-item .delete-button {
            position: absolute;
            top: -10px;
            right: -10px;
            background: #FF4D4D;
            color: white;
            border: none;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            line-height: 24px;
            text-align: center;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s ease, transform 0.1s ease;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }
        .image-item .delete-button:hover {
            background: #E63939;
            transform: scale(1.1);
        }
        .image-item .delete-button:active {
            transform: scale(0.95);
        }
        .delete-product-button {
            background: #DC3545;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 5px 10px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }
        .delete-product-button:hover {
            background: #C82333;
            transform: scale(1.05);
        }
        .delete-product-button:active {
            transform: scale(0.95);
        }
    </style>
</head>
<body>
   <?php include __DIR__ . '/header.php'; ?>

    
    <section class="manage-products container">
        <h2>Manage Products - <?php echo htmlspecialchars($supplier['name']); ?></h2>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <!-- Add New Product -->
        <div class="section">
            <h3>Add New Product</h3>
            <form method="post" class="add-product-form" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group">
                    <label for="name">Product Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description"></textarea>
                </div>
                <div class="form-group">
                    <label for="category_id">Category</label>
                    <select id="category_id" name="category_id" required>
                        <option value="">Select Category</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="brand">Brand</label>
                    <input type="text" id="brand" name="brand" required>
                </div>
                <div class="form-group">
                    <label for="price">Retail Price (LKR)</label>
                    <input type="number" id="price" name="price" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="cost_price">Cost Price (LKR)</label>
                    <input type="number" id="cost_price" name="cost_price" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="stock_quantity">Stock Quantity</label>
                    <input type="number" id="stock_quantity" name="stock_quantity" required>
                </div>
                <div class="form-group">
                    <label for="main_image">Main Image</label>
                    <input type="file" id="main_image" name="main_image" accept="image/jpeg,image/png,image/gif">
                </div>
                <div class="form-group">
                    <label for="additional_images">Additional Images (Select multiple)</label>
                    <input type="file" id="additional_images" name="additional_images[]" multiple accept="image/jpeg,image/png,image/gif">
                </div>
                <button type="submit" name="add_product" class="action-button">Add Product</button>
            </form>
        </div>

        <!-- Existing Products -->
        <div class="section">
            <h3>Existing Products</h3>
            <?php if (empty($products)): ?>
                <p>No products found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Description</th>
                            <th>Main Image</th>
                            <th>Additional Images</th>
                            <th>Cost Price (LKR)</th>
                            <th>Stock Quantity</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <?php
                            $main_image = $product['main_image'] ? "../uploads/" . $product['main_image'] : '';
                            $additional_images = getProductImages($product['id']);
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($product['name']); ?></td>
                                <td><?php echo htmlspecialchars($product['description'] ?: '-'); ?></td>
                                <td>
                                    <?php if ($main_image): ?>
                                        <img src="<?php echo htmlspecialchars($main_image); ?>" alt="Main Image" class="image-preview">
                                    <?php else: ?>
                                        No main image
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="image-list">
                                        <?php if (empty($additional_images)): ?>
                                            <p>No additional images</p>
                                        <?php else: ?>
                                            <?php foreach ($additional_images as $img): ?>
                                                <?php if (!$img['is_main']): ?>
                                                    <div class="image-item">
                                                        <img src="../uploads/<?php echo htmlspecialchars($img['image_path']); ?>" alt="Additional Image">
                                                        <form method="post" style="display: inline;">
                                                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                                            <input type="hidden" name="image_id" value="<?php echo $img['id']; ?>">
                                                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                                            <button type="submit" name="delete_image" class="delete-button" title="Delete Image" aria-label="Delete this image">
                                                                <i class="fas fa-trash-alt"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><?php echo (defined('CURRENCY') ? CURRENCY : 'LKR') . ' ' . number_format($product['cost_price'], 2); ?></td>
                                <td><?php echo $product['stock_quantity']; ?></td>
                                <td>
                                    <form method="post" class="inline-form" enctype="multipart/form-data">
                                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                        <input type="text" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required placeholder="Product Name">
                                        <textarea name="description" placeholder="Description"><?php echo htmlspecialchars($product['description'] ?: ''); ?></textarea>
                                        <input type="number" name="cost_price" value="<?php echo $product['cost_price']; ?>" step="0.01" required placeholder="Cost Price">
                                        <input type="number" name="stock_quantity" value="<?php echo $product['stock_quantity']; ?>" required placeholder="Stock">
                                        <input type="file" name="main_image" accept="image/jpeg,image/png,image/gif">
                                        <label><input type="checkbox" name="remove_main_image" value="1"> Remove Main Image</label>
                                        <input type="file" name="additional_images[]" multiple accept="image/jpeg,image/png,image/gif">
                                        <button type="submit" name="update_product" class="action-button">Update</button>
                                        <button type="submit" name="delete_product" class="delete-product-button" onclick="return confirm('Are you sure you want to delete this product?');" title="Delete Product" aria-label="Delete this product">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </section>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="../assets/js/main.js"></script>
</body>
</html>