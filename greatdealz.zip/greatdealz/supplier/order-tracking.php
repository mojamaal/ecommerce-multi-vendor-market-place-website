<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

// Initialize session and generate CSRF token
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isSupplier()) {
    header('Location: ../login.php');
    exit;
}

$supplier = getSupplierById($_SESSION['supplier_id']);
if (!$supplier) {
    die("Supplier not found.");
}

$orders = getSupplierOrders($supplier['id']);

// Function to validate CSRF token
function validateCSRF($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!validateCSRF($_POST['csrf_token'] ?? '')) {
        $_SESSION['error_message'] = "CSRF token validation failed.";
        header('Location: order-tracking.php');
        exit;
    }

    // Update tracking information
    if (isset($_POST['update_tracking'])) {
        $order_id = (int)$_POST['order_id'];
        $tracking_number = mysqli_real_escape_string($conn, $_POST['tracking_number']);
        $carrier = mysqli_real_escape_string($conn, $_POST['carrier']);
        if (updateDeliveryTracking($order_id, $supplier['id'], $tracking_number, $carrier)) {
            $_SESSION['success_message'] = "Tracking information updated successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to update tracking information.";
        }
        header('Location: order-tracking.php');
        exit;
    }

    // Update order status
    if (isset($_POST['update_status'])) {
        $order_id = (int)$_POST['order_id'];
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        if (updateOrderStatus($order_id, $supplier['id'], $status)) {
            $_SESSION['success_message'] = "Order status updated successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to update order status.";
        }
        header('Location: order-tracking.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Tracking - Greatdealz</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome/css/all.min.css">
    <style>
        .order-tracking { max-width: 1200px; margin: 20px auto; padding: 20px; background: #fff; border-radius: 10px; box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1); }
        .order-tracking h2 { font-size: 2rem; color: #6B7280; margin-bottom: 20px; }
        .order-tracking table { width: 100%; border-collapse: separate; border-spacing: 0; background: #fff; box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; overflow: hidden; }
        .order-tracking th { background: #FF6F61; color: #fff; padding: 15px 20px; font-size: 1.1rem; text-align: left; }
        .order-tracking td { padding: 15px 20px; color: #6B7280; font-size: 1rem; border-bottom: 1px solid #eee; vertical-align: middle; }
        .order-tracking tr:last-child td { border-bottom: none; }
        .order-tracking tr:hover { background: #f5f5f5; }
        .order-tracking form { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        .order-tracking input[type="text"], .order-tracking select { padding: 8px; border: 1px solid #6B7280; border-radius: 5px; font-size: 0.95rem; width: 150px; }
        .order-tracking select { width: 120px; }
        .order-tracking button { padding: 8px 15px; background: #FF6F61; color: #fff; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s ease; font-size: 0.95rem; }
        .order-tracking button:hover { background: #E65B50; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .alert-success { background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .alert-error { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
    </style>
</head>
<body>
        <?php include __DIR__ . '/header.php'; ?>
    <section class="order-tracking container">
        <h2>Order Tracking - <?php echo htmlspecialchars($supplier['name']); ?></h2>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (empty($orders)): ?>
            <p>No orders found.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Date</th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Status</th>
                        <th>Tracking Number</th>
                        <th>Carrier</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?php echo $order['order_id']; ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></td>
                            <td><?php echo htmlspecialchars($order['name']); ?></td>
                            <td><?php echo (int)$order['quantity']; ?></td>
                            <td><?php echo ucfirst($order['status']); ?></td>
                            <td><?php echo htmlspecialchars(getDeliveryTracking($order['order_id'], $supplier['id'])['tracking_number'] ?: '-'); ?></td>
                            <td><?php echo htmlspecialchars(getDeliveryTracking($order['order_id'], $supplier['id'])['carrier'] ?: '-'); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                    <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                    <select name="status" required>
                                        <option value="pending" <?php echo $order['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="processing" <?php echo $order['status'] === 'processing' ? 'selected' : ''; ?>>Processing</option>
                                        <option value="shipped" <?php echo $order['status'] === 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                                        <option value="delivered" <?php echo $order['status'] === 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                        <option value="cancelled" <?php echo $order['status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                    </select>
                                    <button type="submit" name="update_status" class="action-button">Update Status</button>
                                </form>
                                <form method="post" style="display:inline; margin-left: 10px;">
                                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                    <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                    <input type="text" name="tracking_number" value="<?php echo htmlspecialchars(getDeliveryTracking($order['order_id'], $supplier['id'])['tracking_number'] ?: ''); ?>" placeholder="Tracking Number">
                                    <input type="text" name="carrier" value="<?php echo htmlspecialchars(getDeliveryTracking($order['order_id'], $supplier['id'])['carrier'] ?: ''); ?>" placeholder="Carrier">
                                    <button type="submit" name="update_tracking" class="action-button">Update Tracking</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="../assets/js/main.js"></script>
</body>
</html>