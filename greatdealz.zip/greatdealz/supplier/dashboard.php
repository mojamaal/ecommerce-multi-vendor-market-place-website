<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

// Initialize session and generate CSRF token
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isSupplier()) {
    header('Location: ../login.php');
    exit;
}

$supplier = getSupplierById($_SESSION['supplier_id']);
if (!$supplier) {
    die("Supplier not found.");
}

// Function to validate CSRF token
function validateCSRF($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

$orders = getSupplierOrders($supplier['id']) ?: [];
$invoices = getInvoices($supplier['id']) ?: [];
$ratings = getRatingsReviews($supplier['id']) ?: [];
$coupons = getCoupons($supplier['id']) ?: [];

// Get bank details with error handling
$bank_details = null;
try {
    $stmt = $conn->prepare("SELECT * FROM supplier_bank_details WHERE supplier_id = ?");
    $stmt->bind_param("i", $supplier['id']);
    $stmt->execute();
    $bank_details = $stmt->get_result()->fetch_assoc();
    $stmt->close();
} catch (Exception $e) {
    error_log("Error fetching bank details: " . $e->getMessage());
}

// Handle form submissions with CSRF validation
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!validateCSRF($_POST['csrf_token'] ?? '')) {
        die("CSRF token validation failed.");
    }

    if (isset($_POST['update_profile'])) {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $contact_email = mysqli_real_escape_string($conn, $_POST['contact_email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);
        
        if (updateSupplierProfile($supplier['id'], $name, $contact_email, $phone, $address)) {
            $_SESSION['success_message'] = "Profile updated successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to update profile.";
        }
        header('Location: dashboard.php');
        exit;
    }

    if (isset($_POST['update_bank'])) {
        $bank_name = mysqli_real_escape_string($conn, $_POST['bank_name']);
        $account_number = mysqli_real_escape_string($conn, $_POST['account_number']);
        $account_holder = mysqli_real_escape_string($conn, $_POST['account_holder']);
        $ifsc_code = mysqli_real_escape_string($conn, $_POST['ifsc_code']);
        
        if (updateSupplierBankDetails($supplier['id'], $bank_name, $account_number, $account_holder, $ifsc_code)) {
            $_SESSION['success_message'] = "Bank details updated successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to update bank details.";
        }
        header('Location: dashboard.php');
        exit;
    }

    if (isset($_POST['update_order'])) {
        $order_id = (int)$_POST['order_id'];
        $status = $_POST['status'];
        
        if (updateOrderStatus($order_id, $supplier['id'], $status)) {
            if ($status === 'shipped') {
                $tracking_number = $_POST['tracking_number'] ?? '';
                $carrier = $_POST['carrier'] ?? '';
                updateDeliveryTracking($order_id, $supplier['id'], $tracking_number, $carrier);
            }
            $_SESSION['success_message'] = "Order status updated successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to update order status.";
        }
        header('Location: dashboard.php');
        exit;
    }

    if (isset($_POST['create_coupon'])) {
        $code = mysqli_real_escape_string($conn, $_POST['code']);
        $discount = (float)$_POST['discount'];
        $valid_from = $_POST['valid_from'];
        $valid_to = $_POST['valid_to'];
        
        if (createCoupon($supplier['id'], $code, $discount, $valid_from, $valid_to)) {
            $_SESSION['success_message'] = "Coupon created successfully.";
        } else {
            $_SESSION['error_message'] = "Failed to create coupon.";
        }
        header('Location: dashboard.php');
        exit;
    }
}

$start_date = date('Y-m-d', strtotime('-30 days'));
$end_date = date('Y-m-d');
$sales_report = getSalesReport($supplier['id'], $start_date, $end_date) ?: [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Dashboard - Greatdealz</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

    <style>
        .dashboard { max-width: 1200px; margin: 20px auto; padding: 20px; background: #fff; border-radius: 10px; box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1); }
        .dashboard h2 { font-size: 2rem; color: #6B7280; margin-bottom: 20px; }
        .dashboard .section { margin-bottom: 30px; }
        .dashboard table { width: 100%; border-collapse: collapse; background: #fff; box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; overflow: hidden; }
        .dashboard th { background: #FF6F61; color: #fff; padding: 15px; }
        .dashboard td { padding: 15px; color: #6B7280; border-bottom: 1px solid #eee; }
        .dashboard tr:hover { background: #f5f5f5; }
        .dashboard .form-group { margin-bottom: 15px; }
        .dashboard .form-group label { display: block; margin-bottom: 5px; font-size: 1rem; color: #6B7280; }
        .dashboard .form-group input, .dashboard .form-group select, .dashboard .form-group textarea { width: 100%; padding: 10px; border: 1px solid #6B7280; border-radius: 5px; font-size: 1rem; transition: border-color 0.3s ease; }
        .dashboard .form-group input:focus, .dashboard .form-group select:focus, .dashboard .form-group textarea:focus { border-color: #FF6F61; outline: none; }
        .chart-container { width: 100%; height: 300px; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .alert-success { background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .alert-error { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
        .inline-form { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        .inline-form input, .inline-form select { width: auto; min-width: 80px; }
        .inline-form button { white-space: nowrap; }
    </style>
</head>
<body>
   <?php include __DIR__ . '/header.php'; ?>
    
    <section class="dashboard container">
        <h2>Supplier Dashboard - <?php echo htmlspecialchars($supplier['name']); ?></h2>
        
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>
        
        <!-- Profile Management -->
        <div class="section">
            <h3>Profile Management</h3>
            <form method="post" class="add-product-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group">
                    <label for="name">Company Name</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($supplier['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="contact_email">Contact Email</label>
                    <input type="email" id="contact_email" name="contact_email" value="<?php echo htmlspecialchars($supplier['contact_email']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($supplier['phone'] ?: ''); ?>">
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address" name="address"><?php echo htmlspecialchars($supplier['address'] ?: ''); ?></textarea>
                </div>
                <button type="submit" name="update_profile" class="action-button">Update Profile</button>
            </form>
            
            <h4>Bank Details</h4>
            <form method="post" class="add-product-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group">
                    <label for="bank_name">Bank Name</label>
                    <input type="text" id="bank_name" name="bank_name" value="<?php echo htmlspecialchars($bank_details['bank_name'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="account_number">Account Number</label>
                    <input type="text" id="account_number" name="account_number" value="<?php echo htmlspecialchars($bank_details['account_number'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="account_holder">Account Holder</label>
                    <input type="text" id="account_holder" name="account_holder" value="<?php echo htmlspecialchars($bank_details['account_holder'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="ifsc_code">IFSC Code</label>
                    <input type="text" id="ifsc_code" name="ifsc_code" value="<?php echo htmlspecialchars($bank_details['ifsc_code'] ?? ''); ?>" required>
                </div>
                <button type="submit" name="update_bank" class="action-button">Update Bank Details</button>
            </form>
        </div>

        <!-- Product Management -->
        <div class="section">
            <h3>Product Management</h3>
            <p><a href="manage-products.php" class="action-button">Manage Products</a></p>
        </div>

        <!-- Order Management -->
        <div class="section">
            <h3>Order Management</h3>
            <?php if (empty($orders)): ?>
                <p>No orders found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <?php
                            $tracking_info = [];
                            if (function_exists('getDeliveryTracking')) {
                                $tracking_info = getDeliveryTracking($order['order_id'], $supplier['id']) ?: [];
                            }
                            ?>
                            <tr>
                                <td><?php echo $order['order_id']; ?></td>
                                <td><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></td>
                                <td><?php echo htmlspecialchars($order['name']); ?></td>
                                <td><?php echo $order['quantity']; ?></td>
                                <td><?php echo ucfirst($order['status']); ?></td>
                                <td>
                                    <form method="post" class="inline-form">
                                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                        <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                        <select name="status" required>
                                            <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="accepted" <?php echo $order['status'] == 'accepted' ? 'selected' : ''; ?>>Accepted</option>
                                            <option value="shipped" <?php echo $order['status'] == 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                                            <option value="delivered" <?php echo $order['status'] == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                            <option value="returned" <?php echo $order['status'] == 'returned' ? 'selected' : ''; ?>>Returned</option>
                                            <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                        </select>
                                        <input type="text" name="tracking_number" placeholder="Tracking Number" value="<?php echo htmlspecialchars($tracking_info['tracking_number'] ?? ''); ?>">
                                        <input type="text" name="carrier" placeholder="Carrier" value="<?php echo htmlspecialchars($tracking_info['carrier'] ?? ''); ?>">
                                        <button type="submit" name="update_order" class="action-button">Update</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Financial Management -->
        <div class="section">
            <h3>Financial Management</h3>
            <h4>Invoices</h4>
            <?php if (empty($invoices)): ?>
                <p>No invoices found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Invoice ID</th>
                            <th>Order Date</th>
                            <th>Amount (LKR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($invoices as $invoice): ?>
                            <tr>
                                <td><?php echo $invoice['id']; ?></td>
                                <td><?php echo date('Y-m-d', strtotime($invoice['order_date'])); ?></td>
                                <td><?php echo (defined('CURRENCY') ? CURRENCY : 'LKR') . ' ' . number_format($invoice['amount'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            <p>Commission Rate: 10% (example)</p>
        </div>

        <!-- Performance Analytics -->
        <div class="section">
            <h3>Performance Analytics</h3>
            <h4>Sales Report (Last 30 Days)</h4>
            <?php if (empty($sales_report)): ?>
                <p>No sales data available for the last 30 days.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Total Quantity</th>
                            <th>Total Sales (LKR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sales_report as $report): ?>
                            <tr>
                                <td><?php echo $report['sale_date']; ?></td>
                                <td><?php echo $report['total_quantity']; ?></td>
                                <td><?php echo (defined('CURRENCY') ? CURRENCY : 'LKR') . ' ' . number_format($report['total_sales'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            
            <h4>Ratings & Reviews</h4>
            <?php if (empty($ratings)): ?>
                <p>No ratings or reviews available.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Rating</th>
                            <th>Review</th>
                            <th>Customer</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ratings as $rating): ?>
                            <tr>
                                <td><?php echo $rating['rating']; ?>/5</td>
                                <td><?php echo htmlspecialchars($rating['review'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($rating['first_name'] . ' ' . $rating['last_name']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($rating['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Marketing & Promotion Tools -->
        <div class="section">
            <h3>Marketing & Promotion Tools</h3>
            <form method="post" class="add-product-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div class="form-group">
                    <label for="code">Coupon Code</label>
                    <input type="text" id="code" name="code" required>
                </div>
                <div class="form-group">
                    <label for="discount">Discount (%)</label>
                    <input type="number" id="discount" name="discount" min="0" max="100" required>
                </div>
                <div class="form-group">
                    <label for="valid_from">Valid From</label>
                    <input type="date" id="valid_from" name="valid_from" required>
                </div>
                <div class="form-group">
                    <label for="valid_to">Valid To</label>
                    <input type="date" id="valid_to" name="valid_to" required>
                </div>
                <button type="submit" name="create_coupon" class="action-button">Create Coupon</button>
            </form>
            
            <h4>Active Coupons</h4>
            <?php if (empty($coupons)): ?>
                <p>No active coupons.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Discount</th>
                            <th>Valid From</th>
                            <th>Valid To</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($coupons as $coupon): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($coupon['code']); ?></td>
                                <td><?php echo $coupon['discount'] . '%'; ?></td>
                                <td><?php echo date('Y-m-d', strtotime($coupon['valid_from'])); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($coupon['valid_to'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Logistics Integration -->
        <div class="section">
            <h3>Logistics Integration</h3>
            <p>Delivery tracking is updated with order status changes.</p>
        </div>
    </section>
    
   <?php include __DIR__ . '/../includes/footer.php'; ?>
   <script src="../assets/js/main.js"></script>
</body>
</html>