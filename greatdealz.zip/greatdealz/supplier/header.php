<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Greatdealz - Supplier Portal</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <nav class="admin-nav">
        <div class="nav-container">
          <a href="<?php echo SITE_URL; ?>supplier/dashboard.php" class="nav-logo">Greatdealz Supplier</a>
            <div class="nav-links">
               <a href="<?php echo SITE_URL; ?>supplier/dashboard.php">Dashboard</a>
            <a href="<?php echo SITE_URL; ?>supplier/manage-products.php">Manage Products</a>
            <a href="<?php echo SITE_URL; ?>supplier/order-tracking.php">Order Tracking</a>
             <a href="<?php echo SITE_URL; ?>supplier/supplier-reports.php">Reporting</a>
              <a href="<?php echo SITE_URL; ?>supplier/supplier-profile.php">Profile Management</a>
              <a href="<?php echo SITE_URL; ?>supplier/supplier-coupons.php">Coupon Management</a>
               <a href="<?php echo SITE_URL; ?>logout.php">Logout</a>

           
                    </div>
        </div>
    </nav>
</body>
</html>