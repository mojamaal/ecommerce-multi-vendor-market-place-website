document.addEventListener('DOMContentLoaded', function() {
    // Add any admin-specific JavaScript functionality here
    console.log('Admin panel JavaScript loaded');

    // Approve supplier (example for admin panel)
    const approveButtons = document.querySelectorAll('.approve-supplier');
    approveButtons.forEach(button => {
        button.addEventListener('click', () => {
            const supplierId = button.dataset.supplierId;
            fetch('admin/suppliers.php?action=approve', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `supplier_id=${supplierId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Supplier approved successfully!');
                    window.location.reload();
                } else {
                    alert('Error approving supplier.');
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });
});