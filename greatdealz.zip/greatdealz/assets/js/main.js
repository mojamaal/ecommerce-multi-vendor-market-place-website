function addToCart(productId, quantity) {
    fetch('cart.php?action=add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `product_id=${productId}&quantity=${quantity}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Product added to cart!');
        } else {
            alert('Error adding product to cart.');
        }
    })
    .catch(error => console.error('Error:', error));
}

// Hero section advanced 3D animation with floating cubes and mouse tilt
document.addEventListener('DOMContentLoaded', () => {
    const hero = document.querySelector('.hero');
    if (hero) {
        hero.addEventListener('mousemove', (e) => {
            const x = (e.clientX / window.innerWidth - 0.5) * 10; // Subtle tilt
            const y = (e.clientY / window.innerHeight - 0.5) * 10;
            hero.style.transform = `perspective(1000px) rotateX(${y}deg) rotateY(${x}deg)`;
        });
        
        hero.addEventListener('mouseleave', () => {
            hero.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
        });
    }

    // AJAX product filtering
    function filterProducts(categoryId) {
        fetch(`products.php?category=${categoryId}`)
            .then(response => response.text())
            .then(data => {
                document.querySelector('.product-grid').innerHTML = data;
            });
    }

    // Form validation for supplier registration and login
    const forms = document.querySelectorAll('.add-product-form');
    forms.forEach(form => {
        form.addEventListener('submit', (e) => {
            const email = form.querySelector('input[type="email"]');
            const requiredFields = form.querySelectorAll('input[required], textarea[required]');
            let valid = true;

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    valid = false;
                    field.style.borderColor = '#FF6F61';
                } else {
                    field.style.borderColor = '#d1d5db';
                }
            });

            if (email && !email.value.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                valid = false;
                email.style.borderColor = '#FF6F61';
                alert('Please enter a valid email address.');
            }

            if (!valid) {
                e.preventDefault();
                alert('Please fill in all required fields correctly.');
            }
        });
    });

    // Dynamic order status update in supplier dashboard
    const orderForms = document.querySelectorAll('.dashboard form');
    orderForms.forEach(form => {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (response.ok) {
                    window.location.reload();
                } else {
                    alert('Error updating order status.');
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });

    // Real-time stock quantity validation
    const stockInputs = document.querySelectorAll('input[name="stock_quantity"]');
    stockInputs.forEach(input => {
        input.addEventListener('input', () => {
            if (input.value < 0) {
                input.value = 0;
                alert('Stock quantity cannot be negative.');
            }
        });
    });
});