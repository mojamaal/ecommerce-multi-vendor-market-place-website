<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

$category_id = isset($_GET['category']) && $_GET['category'] !== '' ? (int)$_GET['category'] : null;
$brand_id = isset($_GET['brand']) && $_GET['brand'] !== '' ? $_GET['brand'] : null;
$price_min = isset($_GET['price_min']) && $_GET['price_min'] !== '' ? (float)$_GET['price_min'] : null;
$price_max = isset($_GET['price_max']) && $_GET['price_max'] !== '' ? (float)$_GET['price_max'] : null;
$search_query = isset($_GET['search']) && $_GET['search'] !== '' ? trim($_GET['search']) : null;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'newest';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

$sort_query = match($sort) {
    'price_low' => 'p.price ASC',
    'price_high' => 'p.price DESC',
    default => 'p.created_at DESC'
};

$products = getProducts($category_id, $brand_id, $price_min, $price_max, $sort_query, $per_page, $offset, $search_query);
$categories = $conn->query("SELECT * FROM categories WHERE parent_id IS NULL")->fetch_all(MYSQLI_ASSOC);
$brands = $conn->query("SELECT DISTINCT brand FROM products WHERE status = 'active'")->fetch_all(MYSQLI_ASSOC);

// Calculate total products using prepared statements
$total_query = "SELECT COUNT(*) FROM products p WHERE p.status = 'active'";
$params = [];
$types = '';

if ($category_id !== null) {
    $total_query .= " AND p.category_id = ?";
    $params[] = $category_id;
    $types .= 'i';
}
if ($brand_id !== null) {
    $total_query .= " AND p.brand = ?";
    $params[] = $brand_id;
    $types .= 's';
}
if ($price_min !== null) {
    $total_query .= " AND p.price >= ?";
    $params[] = $price_min;
    $types .= 'd';
}
if ($price_max !== null) {
    $total_query .= " AND p.price <= ?";
    $params[] = $price_max;
    $types .= 'd';
}
if ($search_query !== null) {
    $total_query .= " AND p.name LIKE ?";
    $params[] = '%' . $search_query . '%';
    $types .= 's';
}

$stmt = $conn->prepare($total_query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$total_products = $stmt->get_result()->fetch_row()[0];
$total_pages = ceil($total_products / $per_page);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Greatdealz</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="products-page container">
        <h2>Our Products</h2>
        <div class="products-layout">
            <!-- Sidebar for Filters -->
            <aside class="products-sidebar">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" id="search-input" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($search_query ?? ''); ?>">
                </div>
                <div class="filters">
                    <div class="filter-group">
                        <label for="category-filter">Category</label>
                        <select id="category-filter" name="category">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>" <?php echo $category_id == $category['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="brand-filter">Brand</label>
                        <select id="brand-filter" name="brand">
                            <option value="">All Brands</option>
                            <?php foreach ($brands as $brand): ?>
                                <option value="<?php echo htmlspecialchars($brand['brand']); ?>" <?php echo $brand_id == $brand['brand'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($brand['brand']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Price Range</label>
                        <div class="price-filter">
                            <input type="number" id="price_min" name="price_min" value="<?php echo $price_min ?: ''; ?>" min="0" step="0.01" placeholder="Min">
                            <input type="number" id="price_max" name="price_max" value="<?php echo $price_max ?: ''; ?>" min="0" step="0.01" placeholder="Max">
                        </div>
                    </div>
                    <div class="filter-group">
                        <label for="sort-filter">Sort By</label>
                        <select id="sort-filter" name="sort">
                            <option value="newest" <?php echo $sort == 'newest' ? 'selected' : ''; ?>>Newest</option>
                            <option value="price_low" <?php echo $sort == 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                            <option value="price_high" <?php echo $sort == 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                        </select>
                    </div>
                    <button id="apply-filters" class="action-button">Apply Filters</button>
                    <button id="reset-filters" class="action-button reset-button">Reset Filters</button>
                </div>
            </aside>
            
            <!-- Main Content -->
            <div class="products-main">
                <div class="products-controls">
                    <div class="view-toggle">
                        <button id="grid-view" class="active"><i class="fas fa-th"></i></button>
                        <button id="list-view"><i class="fas fa-list"></i></button>
                    </div>
                </div>
                
                <div class="product-grid" id="product-grid">
                    <?php if (empty($products)): ?>
                        <p>No products found matching your criteria.</p>
                    <?php else: ?>
                        <?php foreach ($products as $product): ?>
                            <div class="product-card">
                                <img src="<?php echo $product['image_path'] ?: 'assets/images/placeholder.jpg'; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p><?php echo CURRENCY . ' ' . number_format($product['price'], 2); ?></p>
                                <p class="availability"><?php echo $product['stock_quantity'] > 0 ? 'In Stock' : 'Out of Stock'; ?></p>
                                <a href="product-details.php?id=<?php echo $product['id']; ?>" class="view-details">View Details</a>
                                <button onclick="addToCart(<?php echo $product['id']; ?>, 1)" class="add-to-cart" <?php echo $product['stock_quantity'] <= 0 ? 'disabled' : ''; ?>>Add to Cart</button>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <div class="pagination">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&category=<?php echo $category_id; ?>&brand=<?php echo $brand_id; ?>&price_min=<?php echo $price_min; ?>&price_max=<?php echo $price_max; ?>&sort=<?php echo $sort; ?>&search=<?php echo urlencode($search_query ?? ''); ?>" class="<?php echo $page == $i ? 'active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
    <script>
        document.getElementById('category-filter').addEventListener('change', updateFilters);
        document.getElementById('brand-filter').addEventListener('change', updateFilters);
        document.getElementById('price_min').addEventListener('change', updateFilters);
        document.getElementById('price_max').addEventListener('change', updateFilters);
        document.getElementById('sort-filter').addEventListener('change', updateFilters);
        document.getElementById('apply-filters').addEventListener('click', updateFilters);
        document.getElementById('search-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                updateFilters();
            }
        });

        function updateFilters() {
            const category = document.getElementById('category-filter').value;
            const brand = document.getElementById('brand-filter').value;
            const priceMin = document.getElementById('price_min').value || '';
            const priceMax = document.getElementById('price_max').value || '';
            const sort = document.getElementById('sort-filter').value;
            const search = document.getElementById('search-input').value || '';
            const query = `?category=${category}&brand=${brand}&price_min=${priceMin}&price_max=${priceMax}&sort=${sort}&search=${encodeURIComponent(search)}`;
            window.location.href = query;
        }

        document.getElementById('reset-filters').addEventListener('click', function() {
            document.getElementById('category-filter').value = '';
            document.getElementById('brand-filter').value = '';
            document.getElementById('price_min').value = '';
            document.getElementById('price_max').value = '';
            document.getElementById('sort-filter').value = 'newest';
            document.getElementById('search-input').value = '';
            window.location.href = '?sort=newest';
        });

        document.getElementById('grid-view').addEventListener('click', function() {
            document.getElementById('product-grid').classList.remove('list-view');
            this.classList.add('active');
            document.getElementById('list-view').classList.remove('active');
        });

        document.getElementById('list-view').addEventListener('click', function() {
            document.getElementById('product-grid').classList.add('list-view');
            this.classList.add('active');
            document.getElementById('grid-view').classList.remove('active');
        });
    </script>
</body>
</html>