<?php
echo password_hash('hi123', PASSWORD_BCRYPT);
?>