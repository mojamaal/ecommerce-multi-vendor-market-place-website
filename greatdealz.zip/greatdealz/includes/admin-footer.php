<footer>
    <div class="footer-content container">
        <p>&copy; <?php echo date('Y'); ?> Greatdealz Admin Panel. All rights reserved.</p>
    </div>
</footer>