<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

if (!isAdmin()) {
    header('Location: ../login.php');
    exit;
}
?>
<nav class="admin-nav">
    <div class="nav-container container">
        <div class="nav-logo">Greatdealz Admin</div>
        <div class="nav-links">
            <a href="<?php echo SITE_URL; ?>admin/index.php">Dashboard</a>
            <a href="<?php echo SITE_URL; ?>admin/products.php">Products</a>
            <a href="<?php echo SITE_URL; ?>admin/orders.php">Orders</a>
            <a href="<?php echo SITE_URL; ?>admin/customers.php">Customers</a>
            <a href="<?php echo SITE_URL; ?>admin/categories.php">Categories</a>
            <a href="<?php echo SITE_URL; ?>admin/featured.php">Featured</a>
            <a href="<?php echo SITE_URL; ?>admin/suppliers.php">Suppliers</a>
            <a href="<?php echo SITE_URL; ?>admin/settings.php">Settings</a>
            <a href="<?php echo SITE_URL; ?>admin/admin-reports.php">reporting</a>
            <a href="<?php echo SITE_URL; ?>logout.php">Logout</a>
        </div>
    </div>
</nav>