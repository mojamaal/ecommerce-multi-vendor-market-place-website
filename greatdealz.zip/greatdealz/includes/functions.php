<?php
require_once 'config.php';
session_start();

// User authentication (for customers/admins)
function login($email, $password) {
    global $conn;
    $email = mysqli_real_escape_string($conn, $email);
    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['role'] = $row['role'];
            return true;
        }
    }
    return false;
}

function register($email, $password, $first_name, $last_name) {
    global $conn;
    $email = mysqli_real_escape_string($conn, $email);
    $first_name = mysqli_real_escape_string($conn, $first_name);
    $last_name = mysqli_real_escape_string($conn, $last_name);
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    
    $stmt = $conn->prepare("INSERT INTO users (email, password, first_name, last_name) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $email, $hashed_password, $first_name, $last_name);
    return $stmt->execute();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && $_SESSION['role'] === 'admin';
}

function isSupplier() {
    return isset($_SESSION['supplier_id']);
}

function logout() {
    session_unset();
    session_destroy();
}

// Supplier authentication
function supplierLogin($email, $password) {
    global $conn;
    $email = mysqli_real_escape_string($conn, $email);
    $stmt = $conn->prepare("SELECT id, password FROM suppliers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['supplier_id'] = $row['id'];
            return true;
        }
    }
    return false;
}

// Supplier functions
function registerSupplier($company_name, $contact_email, $phone, $address, $bank_name, $account_number, $account_holder, $ifsc_code, $password) {
    global $conn;
    
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    
    // Insert supplier details with credentials
    $stmt = $conn->prepare("INSERT INTO suppliers (name, contact_email, email, password, phone, address, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
    $stmt->bind_param("ssssss", $company_name, $contact_email, $contact_email, $hashed_password, $phone, $address);
    if (!$stmt->execute()) {
        return false;
    }
    
    $supplier_id = $conn->insert_id;
    
    // Insert bank details
    $stmt = $conn->prepare("INSERT INTO supplier_bank_details (supplier_id, bank_name, account_number, account_holder, ifsc_code) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $supplier_id, $bank_name, $account_number, $account_holder, $ifsc_code);
    if (!$stmt->execute()) {
        $conn->query("DELETE FROM suppliers WHERE id = $supplier_id");
        return false;
    }
    
    // Send registration confirmation email (pseudo-code)
    // mail($contact_email, "Supplier Registration", "Your account has been registered and is pending approval.");
    
    return true;
}

function getSupplierById($supplier_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM suppliers WHERE id = ?");
    $stmt->bind_param("i", $supplier_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function getAllSuppliers() {
    global $conn;
    $stmt = $conn->prepare("SELECT id, name FROM suppliers");
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function updateSupplierProfile($supplier_id, $name, $contact_email, $phone, $address) {
    global $conn;
    $stmt = $conn->prepare("UPDATE suppliers SET name = ?, contact_email = ?, phone = ?, address = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $name, $contact_email, $phone, $address, $supplier_id);
    if ($stmt->execute()) {
        return true;
    }
    return false;
}

function updateSupplierBankDetails($supplier_id, $bank_name, $account_number, $account_holder, $ifsc_code) {
    global $conn;
    $stmt = $conn->prepare("UPDATE supplier_bank_details SET bank_name = ?, account_number = ?, account_holder = ?, ifsc_code = ? WHERE supplier_id = ?");
    $stmt->bind_param("ssssi", $bank_name, $account_number, $account_holder, $ifsc_code, $supplier_id);
    return $stmt->execute();
}

function getSupplierProducts($supplier_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT p.*, p.main_image, sp.stock_quantity, sp.cost_price 
                           FROM products p 
                           JOIN supplier_products sp ON p.id = sp.product_id 
                           WHERE sp.supplier_id = ?");
    $stmt->bind_param("i", $supplier_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function updateSupplierProduct($supplier_id, $product_id, $cost_price, $stock_quantity, $name = null, $description = null) {
    global $conn;
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE supplier_products SET cost_price = ?, stock_quantity = ? WHERE supplier_id = ? AND product_id = ?");
        $stmt->bind_param("diii", $cost_price, $stock_quantity, $supplier_id, $product_id);
        $stmt->execute();
        
        if ($name !== null && $description !== null) {
            $stmt = $conn->prepare("UPDATE products SET name = ?, description = ? WHERE id = ?");
            $stmt->bind_param("ssi", $name, $description, $product_id);
            $stmt->execute();
        }
        
        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Error updating supplier product: " . $e->getMessage());
        return false;
    }
}

function addSupplierProduct($supplier_id, $name, $description, $category_id, $brand, $price, $cost_price, $stock_quantity) {
    global $conn;
    $conn->begin_transaction();
    try {
        // Insert into products table
        $stmt = $conn->prepare("INSERT INTO products (name, description, category_id, brand, price, status) VALUES (?, ?, ?, ?, ?, 'active')");
        $stmt->bind_param("ssisd", $name, $description, $category_id, $brand, $price);
        if (!$stmt->execute()) {
            throw new Exception("Failed to insert product into products table.");
        }

        $product_id = $conn->insert_id;

        // Insert into supplier_products table
        $stmt = $conn->prepare("INSERT INTO supplier_products (supplier_id, product_id, cost_price, stock_quantity) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iidi", $supplier_id, $product_id, $cost_price, $stock_quantity);
        if (!$stmt->execute()) {
            throw new Exception("Failed to link product to supplier.");
        }

        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Error adding supplier product: " . $e->getMessage());
        return false;
    }
}

function getSupplierOrders($supplier_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT oi.order_id, oi.quantity, oi.unit_price, p.name, o.created_at, o.status 
                           FROM order_items oi 
                           JOIN orders o ON oi.order_id = o.id 
                           JOIN products p ON oi.product_id = p.id 
                           WHERE oi.supplier_id = ?");
    $stmt->bind_param("i", $supplier_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function updateOrderStatus($order_id, $supplier_id, $status) {
    global $conn;
    $stmt = $conn->prepare("UPDATE orders o 
                           JOIN order_items oi ON o.id = oi.order_id 
                           SET o.status = ? 
                           WHERE o.id = ? AND oi.supplier_id = ?");
    $stmt->bind_param("sii", $status, $order_id, $supplier_id);
    return $stmt->execute();
}

function updateDeliveryTracking($order_id, $supplier_id, $tracking_number, $carrier) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO delivery_tracking (order_id, supplier_id, tracking_number, carrier) 
                           VALUES (?, ?, ?, ?) 
                           ON DUPLICATE KEY UPDATE tracking_number = ?, carrier = ?");
    $stmt->bind_param("iissss", $order_id, $supplier_id, $tracking_number, $carrier, $tracking_number, $carrier);
    return $stmt->execute();
}

function getDeliveryTracking($order_id, $supplier_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT tracking_number, carrier FROM delivery_tracking WHERE order_id = ? AND supplier_id = ?");
    $stmt->bind_param("ii", $order_id, $supplier_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: ['tracking_number' => '', 'carrier' => ''];
}

function getInvoices($supplier_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT oi.order_id AS id, o.created_at AS order_date, SUM(oi.quantity * oi.unit_price) AS amount 
                           FROM order_items oi 
                           JOIN orders o ON oi.order_id = o.id 
                           WHERE oi.supplier_id = ? AND o.status = 'delivered' 
                           GROUP BY oi.order_id");
    $stmt->bind_param("i", $supplier_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getRatingsReviews($supplier_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT rr.rating, rr.review, rr.created_at, u.first_name, u.last_name 
                           FROM ratings_reviews rr 
                           JOIN users u ON rr.user_id = u.id 
                           JOIN order_items oi ON rr.order_item_id = oi.id 
                           WHERE oi.supplier_id = ?");
    $stmt->bind_param("i", $supplier_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getSalesReport($supplier_id, $start_date, $end_date, $product_id = null) {
    global $conn;
    $query = "SELECT DATE(o.created_at) AS sale_date, 
                     SUM(oi.quantity) AS total_quantity, 
                     SUM(oi.quantity * oi.unit_price) AS total_sales 
              FROM order_items oi 
              JOIN orders o ON oi.order_id = o.id 
              WHERE oi.supplier_id = ? AND o.created_at BETWEEN ? AND ? AND o.status = 'delivered'";
    
    $params = [$supplier_id, $start_date, $end_date];
    $types = 'iss';

    if ($product_id !== null) {
        $query .= " AND oi.product_id = ?";
        $params[] = $product_id;
        $types .= 'i';
    }
    
    $query .= " GROUP BY DATE(o.created_at) ORDER BY sale_date ASC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getAdminSalesReport($start_date, $end_date, $supplier_id = null) {
    global $conn;
    $query = "SELECT DATE(o.created_at) AS sale_date, 
                     SUM(oi.quantity) AS total_quantity, 
                     SUM(oi.quantity * oi.unit_price) AS total_sales 
              FROM order_items oi 
              JOIN orders o ON oi.order_id = o.id 
              WHERE o.created_at BETWEEN ? AND ? AND o.status = 'delivered'";
    
    $params = [$start_date, $end_date];
    $types = 'ss';

    if ($supplier_id !== null) {
        $query .= " AND oi.supplier_id = ?";
        $params[] = $supplier_id;
        $types .= 'i';
    }
    
    $query .= " GROUP BY DATE(o.created_at) ORDER BY sale_date ASC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function createCoupon($supplier_id, $code, $discount, $valid_from, $valid_to) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO coupons (supplier_id, code, discount, valid_from, valid_to) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $supplier_id, $code, $discount, $valid_from, $valid_to);
    return $stmt->execute();
}

function getCoupons($supplier_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM coupons WHERE supplier_id = ? AND valid_to >= CURDATE()");
    $stmt->bind_param("i", $supplier_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getTopSellingProducts($supplier_id, $start_date, $end_date, $limit = 5) {
    global $conn;
    $stmt = $conn->prepare("SELECT p.name, SUM(oi.quantity) AS total_quantity, SUM(oi.quantity * oi.unit_price) AS total_sales 
                           FROM order_items oi 
                           JOIN products p ON oi.product_id = p.id 
                           JOIN orders o ON oi.order_id = o.id 
                           WHERE oi.supplier_id = ? AND o.created_at BETWEEN ? AND ? AND o.status = 'delivered'
                           GROUP BY p.id, p.name 
                           ORDER BY total_quantity DESC 
                           LIMIT ?");
    $stmt->bind_param("issi", $supplier_id, $start_date, $end_date, $limit);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getAdminTopSellingProducts($start_date, $end_date, $limit = 5) {
    global $conn;
    $stmt = $conn->prepare("SELECT p.name, SUM(oi.quantity) AS total_quantity, SUM(oi.quantity * oi.unit_price) AS total_sales 
                           FROM order_items oi 
                           JOIN products p ON oi.product_id = p.id 
                           JOIN orders o ON oi.order_id = o.id 
                           WHERE o.created_at BETWEEN ? AND ? AND o.status = 'delivered'
                           GROUP BY p.id, p.name 
                           ORDER BY total_quantity DESC 
                           LIMIT ?");
    $stmt->bind_param("ssi", $start_date, $end_date, $limit);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Product functions
function getProducts($category_id = null, $brand_id = null, $price_min = null, $price_max = null, $sort = 'p.created_at DESC', $limit = null, $offset = 0, $search_query = null) {
    global $conn;
    $query = "SELECT p.*, pi.image_path FROM products p 
              LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_main = 1 
              WHERE p.status = 'active'";
    
    $params = [];
    $types = '';

    if ($category_id !== null) {
        $query .= " AND p.category_id = ?";
        $params[] = $category_id;
        $types .= 'i';
    }
    if ($brand_id !== null) {
        $query .= " AND p.brand = ?";
        $params[] = $brand_id;
        $types .= 's';
    }
    if ($price_min !== null) {
        $query .= " AND p.price >= ?";
        $params[] = $price_min;
        $types .= 'd';
    }
    if ($price_max !== null) {
        $query .= " AND p.price <= ?";
        $params[] = $price_max;
        $types .= 'd';
    }
    if ($search_query !== null) {
        $query .= " AND p.name LIKE ?";
        $params[] = '%' . $search_query . '%';
        $types .= 's';
    }
    
    $query .= " ORDER BY $sort";
    if ($limit !== null) {
        $query .= " LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        $types .= 'ii';
    }

    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getProductById($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function getProductImages($product_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, image_path, is_main FROM product_images WHERE product_id = ? ORDER BY is_main DESC");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to upload an image and return the file path
function uploadImage($file, $product_id = null, $is_main = false) {
    global $conn;
    $upload_dir = __DIR__ . '/../uploads/';
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $max_file_size = 5 * 1024 * 1024; // 5MB

    if (!in_array($file['type'], $allowed_types) || $file['size'] > $max_file_size) {
        return false;
    }

    $file_name = uniqid() . '_' . basename($file['name']);
    $target_file = $upload_dir . $file_name;

    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        if ($is_main) {
            $stmt = $conn->prepare("UPDATE products SET main_image = ? WHERE id = ?");
            $stmt->bind_param("si", $file_name, $product_id);
            $stmt->execute();
        } else {
            $stmt = $conn->prepare("INSERT INTO product_images (product_id, image_path, is_main) VALUES (?, ?, 0)");
            $stmt->bind_param("is", $product_id, $file_name);
            $stmt->execute();
        }
        return $file_name;
    }
    return false;
}

// Function to update or delete main image
function updateMainImage($product_id, $file = null) {
    global $conn;
    if ($file && is_array($file)) {
        $upload_dir = __DIR__ . '/../uploads/';
        $file_name = uploadImage($file, $product_id, true);
        if ($file_name) {
            return true;
        }
    } elseif ($file === null) { // Delete main image
        $stmt = $conn->prepare("UPDATE products SET main_image = NULL WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        return $stmt->execute();
    }
    return false;
}

// Function to add or update additional images
function updateAdditionalImages($product_id, $files) {
    global $conn;
    $upload_dir = __DIR__ . '/../uploads/';
    $conn->begin_transaction();
    try {
        // Delete existing additional images
        $stmt = $conn->prepare("DELETE FROM product_images WHERE product_id = ? AND is_main = 0");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();

        // Upload new images
        foreach ($files['name'] as $key => $name) {
            if ($files['error'][$key] === UPLOAD_ERR_OK) {
                $file = [
                    'name' => $name,
                    'type' => $files['type'][$key],
                    'size' => $files['size'][$key],
                    'tmp_name' => $files['tmp_name'][$key]
                ];
                uploadImage($file, $product_id, false);
            }
        }
        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Error updating additional images: " . $e->getMessage());
        return false;
    }
}

// Function to delete a specific additional image
function deleteAdditionalImage($image_id, $product_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT image_path FROM product_images WHERE id = ? AND product_id = ? AND is_main = 0");
    $stmt->bind_param("ii", $image_id, $product_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    if ($result) {
        $file_path = __DIR__ . '/../uploads/' . $result['image_path'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }
    $stmt = $conn->prepare("DELETE FROM product_images WHERE id = ? AND product_id = ? AND is_main = 0");
    $stmt->bind_param("ii", $image_id, $product_id);
    return $stmt->execute();
}

// Function to delete a supplier's product
function deleteSupplierProduct($supplier_id, $product_id) {
    global $conn;
    $conn->begin_transaction();
    try {
        // Fetch and delete main image file if it exists
        $stmt = $conn->prepare("SELECT main_image FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        if ($result && $result['main_image']) {
            $main_file_path = __DIR__ . '/../uploads/' . $result['main_image'];
            if (file_exists($main_file_path)) {
                unlink($main_file_path);
            }
        }

        // Delete additional images
        $stmt = $conn->prepare("SELECT image_path FROM product_images WHERE product_id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $images = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        foreach ($images as $img) {
            $file_path = __DIR__ . '/../uploads/' . $img['image_path'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        $stmt = $conn->prepare("DELETE FROM product_images WHERE product_id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();

        // Delete supplier_products record
        $stmt = $conn->prepare("DELETE FROM supplier_products WHERE supplier_id = ? AND product_id = ?");
        $stmt->bind_param("ii", $supplier_id, $product_id);
        $stmt->execute();

        // Delete product
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();

        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Error deleting supplier product: " . $e->getMessage());
        return false;
    }
}

// Cart functions
function addToCart($product_id, $quantity) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = $quantity;
    }
    return true;
}

function updateCartQuantity($product_id, $quantity) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    if (isset($_SESSION['cart'][$product_id]) && $quantity > 0) {
        $_SESSION['cart'][$product_id] = $quantity;
        return true;
    }
    return false;
}

function removeFromCart($product_id) {
    if (isset($_SESSION['cart']) && isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
        return true;
    }
    return false;
}

function getCartItems() {
    global $conn;
    $items = [];
    if (isset($_SESSION['cart'])) {
        $ids = array_keys($_SESSION['cart']);
        if (!empty($ids)) {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $conn->prepare("SELECT p.*, pi.image_path FROM products p 
                                  LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_main = 1 
                                  WHERE p.id IN ($placeholders)");
            $stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
            $stmt->execute();
            $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            foreach ($products as $product) {
                $items[] = [
                    'id' => $product['id'],
                    'name' => $product['name'],
                    'price' => $product['price'],
                    'image_path' => $product['image_path'] ?: 'assets/images/placeholder.jpg',
                    'quantity' => $_SESSION['cart'][$product['id']]
                ];
            }
        }
    }
    return $items;
}

// Order functions
function createOrder($user_id, $shipping_address, $billing_address, $payment_method, $supplier_assignments = []) {
    global $conn;
    $total_amount = 0;
    $cart_items = getCartItems();
    
    foreach ($cart_items as $item) {
        $total_amount += $item['price'] * $item['quantity'];
    }
    
    $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, shipping_address, billing_address, payment_method, estimated_delivery) 
                           VALUES (?, ?, ?, ?, ?, DATE_ADD(CURDATE(), INTERVAL 7 DAY))");
    $stmt->bind_param("idsss", $user_id, $total_amount, $shipping_address, $billing_address, $payment_method);
    
    if ($stmt->execute()) {
        $order_id = $conn->insert_id;
        
        foreach ($cart_items as $item) {
            $supplier_id = null;
            $quantity_to_assign = $item['quantity'];
            if (isset($supplier_assignments[$item['id']]) && is_array($supplier_assignments[$item['id']])) {
                foreach ($supplier_assignments[$item['id']] as $assignment) {
                    $supp_id = (int)$assignment['supplier_id'];
                    $qty = (int)$assignment['quantity'];
                    if ($qty > 0 && $qty <= $quantity_to_assign) {
                        $stmt = $conn->prepare("SELECT stock_quantity FROM supplier_products WHERE supplier_id = ? AND product_id = ?");
                        $stmt->bind_param("ii", $supp_id, $item['id']);
                        $stmt->execute();
                        $supplier_stock = $stmt->get_result()->fetch_assoc();
                        if ($supplier_stock && $supplier_stock['stock_quantity'] >= $qty) {
                            $supplier_id = $supp_id;
                            $quantity_to_assign -= $qty;
                            break;
                        }
                    }
                }
            }

            if (!$supplier_id) {
                $stmt = $conn->prepare("SELECT supplier_id, stock_quantity FROM supplier_products WHERE product_id = ? AND stock_quantity > 0 ORDER BY stock_quantity DESC LIMIT 1");
                $stmt->bind_param("i", $item['id']);
                $stmt->execute();
                $supplier = $stmt->get_result()->fetch_assoc();
                $supplier_id = $supplier ? $supplier['supplier_id'] : null;
            }

            $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, unit_price, supplier_id) 
                                  VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iiidi", $order_id, $item['id'], $item['quantity'], $item['price'], $supplier_id);
            $stmt->execute();

            $stmt = $conn->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?");
            $stmt->bind_param("ii", $item['quantity'], $item['id']);
            $stmt->execute();

            if ($supplier_id) {
                $remaining_quantity = $item['quantity'];
                $stmt = $conn->prepare("SELECT stock_quantity FROM supplier_products WHERE supplier_id = ? AND product_id = ?");
                $stmt->bind_param("ii", $supplier_id, $item['id']);
                $stmt->execute();
                $supplier_stock = $stmt->get_result()->fetch_assoc();
                $decrease_amount = min($remaining_quantity, $supplier_stock['stock_quantity']);
                if ($decrease_amount > 0) {
                    $stmt = $conn->prepare("UPDATE supplier_products SET stock_quantity = stock_quantity - ? WHERE supplier_id = ? AND product_id = ?");
                    $stmt->bind_param("iii", $decrease_amount, $supplier_id, $item['id']);
                    $stmt->execute();
                    $remaining_quantity -= $decrease_amount;
                }

                if ($remaining_quantity > 0) {
                    error_log("Not enough stock to fulfill order for product ID {$item['id']}. Remaining quantity: $remaining_quantity");
                }
            }
        }
        
        unset($_SESSION['cart']);
        return $order_id;
    }
    return false;
}
?>