<footer>
    <div class="footer-content container">
        <div class="footer-section">
            <h3>About Greatdealz</h3>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
            <a href="#">Terms & Conditions</a>
        </div>
        <div class="footer-section">
            <h3>Follow Us</h3>
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div class="footer-section">
            <h3>Contact</h3>
            <p>Email: support@greatdealz.com</p>
            <p>Phone: +94 123 456 789</p>
        </div>
    </div>
</footer>