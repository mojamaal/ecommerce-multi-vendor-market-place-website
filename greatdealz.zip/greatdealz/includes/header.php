<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
?>
<nav>
    <div class="nav-container container">
        <a href="index.php" class="nav-logo">Greatdealz</a>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="products.php">Products</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <?php if (isLoggedIn()): ?>
                <a href="account.php">Account</a>
                <a href="logout.php">Logout</a>
            <?php elseif (isSupplier()): ?>
                <a href="supplier/dashboard.php">Dashboard</a>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
                <a href="supplier-login.php">Supplier Login</a>
                <a href="supplier-registration.php">Supplier Register</a>
            <?php endif; ?>
        </div>
        <div class="nav-cart">
            <a href="cart.php"><i class="fas fa-shopping-cart"></i></a>
        </div>
    </div>
</nav>