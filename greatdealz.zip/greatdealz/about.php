<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Greatdealz</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="about-page container">
        <h2>About Greatdealz</h2>
        <div class="about-content">
            <p>Welcome to Greatdealz, your one-stop online shopping destination for unbeatable deals and exceptional quality. Founded with a passion for delivering value, we strive to bring you a curated selection of products that cater to your every need.</p>
            <p>Our mission is to make shopping seamless, enjoyable, and affordable. With a focus on customer satisfaction, we offer fast delivery, secure payments, and a user-friendly platform designed to enhance your shopping experience.</p>
            <p>At Greatdealz, we believe in building trust and fostering long-lasting relationships with our customers. Join us today and discover why thousands choose Greatdealz for their shopping needs!</p>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>