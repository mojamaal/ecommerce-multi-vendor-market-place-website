<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    // Handle newsletter subscription (e.g., save to database or integrate with email service)
    // For now, just redirect with success message
    $_SESSION['newsletter_success'] = "Thank you for subscribing!";
    header('Location: index.php');
    exit;
}
?>